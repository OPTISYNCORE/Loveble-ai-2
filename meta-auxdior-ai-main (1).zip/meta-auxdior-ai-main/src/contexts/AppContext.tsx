import React, { createContext, useContext, useState, ReactNode } from 'react';

interface Track {
  id: string;
  title: string;
  artist: string;
  duration: string;
  currentTime: string;
  album?: string;
  genre?: string;
  isPlaying?: boolean;
  isLiked?: boolean;
}

interface AppState {
  // Player state
  currentTrack: Track | null;
  isPlaying: boolean;
  volume: number[];
  progress: number[];
  isMuted: boolean;
  isShuffled: boolean;
  repeatMode: 'off' | 'one' | 'all';
  
  // UI state
  theme: 'light' | 'dark' | 'adaptive';
  isWidgetVisible: boolean;
  isHiddenMode: boolean;
  hiddenPin: string;
  introCompleted: boolean;
  
  // Features state
  isEqualizerOpen: boolean;
  eqPreset: 'pop' | 'rock' | 'acoustic' | 'bassBooster' | 'trebleBoost' | 'vocalBoost' | 'headphones' | 'deep' | 'electronic' | 'latin' | 'balanced' | 'custom';
  isSleepTimerActive: boolean;
  sleepTimer: number;
  isDriveModeActive: boolean;
  isDJModeActive: boolean;
  isLyricsModeActive: boolean;
  
  // Premium Features state
  isVisualizerActive: boolean;
  visualizerType: 'equalizer-bars' | 'waveform' | 'particles' | 'neon-flow';
  cloudSyncEnabled: boolean;
  connectedCloudServices: string[];
  isSocialHubOpen: boolean;
  
  // AI state
  isAIAssistOpen: boolean;
  aiRecommendations: Track[];
  
  // Library state
  tracks: Track[];
  playlists: any[];
  isScanning: boolean;
}

interface AppContextType extends AppState {
  // Player actions
  togglePlay: () => void;
  setVolume: (volume: number[]) => void;
  setProgress: (progress: number[]) => void;
  toggleMute: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  playTrack: (track: Track) => void;
  nextTrack: () => void;
  previousTrack: () => void;
  
  // UI actions
  setTheme: (theme: 'light' | 'dark' | 'adaptive') => void;
  toggleWidget: () => void;
  toggleHiddenMode: (pin?: string) => void;
  setIntroCompleted: (completed: boolean) => void;
  
  // Feature actions
  toggleEqualizer: () => void;
  setEQPreset: (preset: 'pop' | 'rock' | 'acoustic' | 'bassBooster' | 'trebleBoost' | 'vocalBoost' | 'headphones' | 'deep' | 'electronic' | 'latin' | 'balanced' | 'custom') => void;
  setSleepTimer: (minutes: number) => void;
  toggleDriveMode: () => void;
  setIsDJModeActive: (active: boolean) => void;
  toggleLyricsMode: () => void;
  
  // Premium Feature actions
  toggleVisualizer: () => void;
  setVisualizerType: (type: 'equalizer-bars' | 'waveform' | 'particles' | 'neon-flow') => void;
  toggleCloudSync: () => void;
  connectCloudService: (service: string) => void;
  toggleSocialHub: () => void;
  
  // AI actions
  toggleAIAssist: () => void;
  getAIRecommendations: () => void;
  
  // Library actions
  scanLibrary: () => void;
  addToPlaylist: (trackId: string, playlistName: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const sampleTracks: Track[] = [
  { id: '1', title: 'Neon Dreams', artist: 'Synthwave Collective', duration: '4:32', currentTime: '1:23', album: 'Digital Nights', genre: 'Electronic', isLiked: false },
  { id: '2', title: 'City Lights', artist: 'Urban Echo', duration: '3:45', currentTime: '0:00', album: 'Metropolitan', genre: 'Pop', isLiked: true },
  { id: '3', title: 'Midnight Drive', artist: 'Retro Vibes', duration: '5:12', currentTime: '0:00', album: 'Night Sessions', genre: 'Synthwave', isLiked: false },
  { id: '4', title: 'Electric Pulse', artist: 'Bass Machine', duration: '4:18', currentTime: '0:00', album: 'Frequency', genre: 'EDM', isLiked: false },
  { id: '5', title: 'Starlight', artist: 'Cosmic Dreams', duration: '6:30', currentTime: '0:00', album: 'Celestial', genre: 'Ambient', isLiked: true },
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>({
    // Player state
    currentTrack: sampleTracks[0],
    isPlaying: false,
    volume: [75],
    progress: [30],
    isMuted: false,
    isShuffled: false,
    repeatMode: 'off',
    
    // UI state
    theme: 'dark',
    isWidgetVisible: false,
    isHiddenMode: false,
    hiddenPin: '',
    introCompleted: localStorage.getItem('intro-completed') === 'true',
    
    // Features state
    isEqualizerOpen: false,
    eqPreset: 'balanced',
    isSleepTimerActive: false,
    sleepTimer: 0,
    isDriveModeActive: false,
    isDJModeActive: false,
    isLyricsModeActive: false,
    
    // Premium Features state
    isVisualizerActive: false,
    visualizerType: 'equalizer-bars',
    cloudSyncEnabled: false,
    connectedCloudServices: [],
    isSocialHubOpen: false,
    
    // AI state
    isAIAssistOpen: false,
    aiRecommendations: [],
    
    // Library state
    tracks: sampleTracks,
    playlists: [
      { id: '1', name: 'My Favorites', trackCount: 12 },
      { id: '2', name: 'Workout Mix', trackCount: 25 },
      { id: '3', name: 'Chill Vibes', trackCount: 18 },
    ],
    isScanning: false,
  });

  const contextValue: AppContextType = {
    ...state,
    
    // Player actions
    togglePlay: () => setState(prev => ({ ...prev, isPlaying: !prev.isPlaying })),
    setVolume: (volume) => setState(prev => ({ ...prev, volume, isMuted: false })),
    setProgress: (progress) => setState(prev => ({ ...prev, progress })),
    toggleMute: () => setState(prev => ({ ...prev, isMuted: !prev.isMuted })),
    toggleShuffle: () => setState(prev => ({ ...prev, isShuffled: !prev.isShuffled })),
    toggleRepeat: () => setState(prev => ({ 
      ...prev, 
      repeatMode: prev.repeatMode === 'off' ? 'all' : prev.repeatMode === 'all' ? 'one' : 'off' 
    })),
    playTrack: (track) => setState(prev => ({ ...prev, currentTrack: track, isPlaying: true })),
    nextTrack: () => {
      const currentIndex = state.tracks.findIndex(t => t.id === state.currentTrack?.id);
      const nextIndex = (currentIndex + 1) % state.tracks.length;
      setState(prev => ({ ...prev, currentTrack: state.tracks[nextIndex] }));
    },
    previousTrack: () => {
      const currentIndex = state.tracks.findIndex(t => t.id === state.currentTrack?.id);
      const prevIndex = currentIndex === 0 ? state.tracks.length - 1 : currentIndex - 1;
      setState(prev => ({ ...prev, currentTrack: state.tracks[prevIndex] }));
    },
    
    // UI actions
    setTheme: (theme) => setState(prev => ({ ...prev, theme })),
    toggleWidget: () => setState(prev => ({ ...prev, isWidgetVisible: !prev.isWidgetVisible })),
    toggleHiddenMode: (pin) => setState(prev => ({ 
      ...prev, 
      isHiddenMode: pin ? pin === '1234' : !prev.isHiddenMode 
    })),
    setIntroCompleted: (completed) => {
      setState(prev => ({ ...prev, introCompleted: completed }));
      localStorage.setItem('intro-completed', completed.toString());
    },
    
    // Feature actions
    toggleEqualizer: () => setState(prev => ({ ...prev, isEqualizerOpen: !prev.isEqualizerOpen })),
    setEQPreset: (preset) => setState(prev => ({ ...prev, eqPreset: preset })),
    setSleepTimer: (minutes) => setState(prev => ({ 
      ...prev, 
      sleepTimer: minutes, 
      isSleepTimerActive: minutes > 0 
    })),
    toggleDriveMode: () => setState(prev => ({ ...prev, isDriveModeActive: !prev.isDriveModeActive })),
    setIsDJModeActive: (active) => setState(prev => ({ ...prev, isDJModeActive: active })),
    toggleLyricsMode: () => setState(prev => ({ ...prev, isLyricsModeActive: !prev.isLyricsModeActive })),
    
    // Premium Feature actions
    toggleVisualizer: () => setState(prev => ({ ...prev, isVisualizerActive: !prev.isVisualizerActive })),
    setVisualizerType: (type) => setState(prev => ({ ...prev, visualizerType: type })),
    toggleCloudSync: () => setState(prev => ({ ...prev, cloudSyncEnabled: !prev.cloudSyncEnabled })),
    connectCloudService: (service) => setState(prev => ({ 
      ...prev, 
      connectedCloudServices: prev.connectedCloudServices.includes(service) 
        ? prev.connectedCloudServices.filter(s => s !== service)
        : [...prev.connectedCloudServices, service]
    })),
    toggleSocialHub: () => setState(prev => ({ ...prev, isSocialHubOpen: !prev.isSocialHubOpen })),
    
    // AI actions
    toggleAIAssist: () => setState(prev => ({ ...prev, isAIAssistOpen: !prev.isAIAssistOpen })),
    getAIRecommendations: () => setState(prev => ({ 
      ...prev, 
      aiRecommendations: sampleTracks.slice(0, 3) 
    })),
    
    // Library actions
    scanLibrary: () => {
      setState(prev => ({ ...prev, isScanning: true }));
      setTimeout(() => {
        setState(prev => ({ ...prev, isScanning: false, tracks: [...sampleTracks] }));
      }, 2000);
    },
    addToPlaylist: (trackId, playlistName) => {
      // Implementation for adding tracks to playlists
      console.log(`Added track ${trackId} to playlist ${playlistName}`);
    },
  };

  return (
    <AppContext.Provider value={contextValue}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}

export const useAppContext = useApp;