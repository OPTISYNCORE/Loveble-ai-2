import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useApp } from "@/contexts/AppContext";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  Repeat,
  Shuffle,
  Heart,
  MoreHorizontal,
  Maximize2,
  Music,
  Sparkles,
} from "lucide-react";

export function MusicPlayer() {
  const {
    currentTrack,
    isPlaying,
    togglePlay,
    volume,
    setVolume,
    progress,
    setProgress,
    isMuted,
    toggleMute,
    isShuffled,
    toggleShuffle,
    repeatMode,
    toggleRepeat,
    nextTrack,
    previousTrack,
  } = useApp();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50">
      {/* Main Player Bar */}
      <div className="glass-card border-t border-card-border backdrop-blur-xl">
        <div className="flex items-center justify-between p-4">
          {/* Track Info */}
          <div className="flex items-center gap-4 flex-1 min-w-0">
            <div className="w-14 h-14 rounded-xl bg-gradient-primary flex items-center justify-center shadow-glow">
              <Music className="w-6 h-6 text-white" />
            </div>
            
            <div className="min-w-0 flex-1">
              <h4 className="font-semibold truncate">{currentTrack?.title || 'No Track'}</h4>
              <p className="text-sm text-foreground-muted truncate">
                {currentTrack?.artist || 'Unknown'} • {currentTrack?.album || 'Unknown'}
              </p>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs bg-music-primary/20 text-music-primary px-2 py-0.5 rounded-full">
                  AI Generated
                </span>
                <Sparkles className="w-3 h-3 text-music-primary" />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                className={currentTrack?.isLiked ? "text-music-danger" : "text-foreground-muted"}
              >
                <Heart className={`w-4 h-4 ${currentTrack?.isLiked ? "fill-current" : ""}`} />
              </Button>
              <Button variant="ghost" size="sm">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Control Center */}
          <div className="flex flex-col items-center gap-2 flex-1 max-w-md">
            {/* Control Buttons */}
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="text-music-primary">
                <Shuffle className="w-4 h-4" />
              </Button>
              
              <Button variant="ghost" size="sm">
                <SkipBack className="w-5 h-5" />
              </Button>
              
              <Button
                onClick={togglePlay}
                className="w-12 h-12 rounded-full bg-gradient-primary hover:shadow-glow transition-all duration-300"
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5 text-white" />
                ) : (
                  <Play className="w-5 h-5 text-white ml-0.5" />
                )}
              </Button>
              
              <Button variant="ghost" size="sm">
                <SkipForward className="w-5 h-5" />
              </Button>
              
              <Button variant="ghost" size="sm" className="text-music-primary">
                <Repeat className="w-4 h-4" />
              </Button>
            </div>

            {/* Progress Bar */}
            <div className="flex items-center gap-3 w-full">
              <span className="text-xs text-foreground-muted min-w-fit">
                {currentTrack?.currentTime || '0:00'}
              </span>
              <Slider
                value={progress}
                onValueChange={setProgress}
                max={100}
                step={1}
                className="flex-1"
              />
              <span className="text-xs text-foreground-muted min-w-fit">
                {currentTrack?.duration || '0:00'}
              </span>
            </div>
          </div>

          {/* Volume & Actions */}
          <div className="flex items-center gap-3 flex-1 justify-end">
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleMute}
              >
                {isMuted || volume[0] === 0 ? (
                  <VolumeX className="w-4 h-4" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </Button>
              
              <Slider
                value={isMuted ? [0] : volume}
                onValueChange={setVolume}
                max={100}
                step={1}
                className="w-20"
              />
            </div>

            <div className="flex items-center gap-1">
              <Button variant="ghost" size="sm" className="text-music-primary">
                <Sparkles className="w-4 h-4" />
              </Button>
              
              <Button variant="ghost" size="sm">
                <Maximize2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* AI Status Bar */}
        <div className="px-4 pb-2">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-music-primary">
              <div className="w-1.5 h-1.5 bg-music-success rounded-full animate-pulse-glow"></div>
              <span>AI Adaptive EQ Active</span>
              <span>•</span>
              <span>Crossfade: 3s</span>
            </div>
            
            <div className="flex items-center gap-4 text-foreground-muted">
              <span>Quality: Hi-Fi (24-bit/192kHz)</span>
              <span>•</span>
              <span>Next: AI Recommendation</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}