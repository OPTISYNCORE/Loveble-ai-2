import { useState } from "react";
import { SidebarTrigger } from "@/components/ui/sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useApp } from "@/contexts/AppContext";
import { AIAssistModal } from "./modals/AIAssistModal";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Search,
  Mic,
  User,
  Bell,
  Settings,
  Sparkles,
  ChevronDown,
  MoreVertical,
  CheckSquare,
  ArrowUpDown,
  Shuffle,
} from "lucide-react";

const navigationTabs = [
  "Playlists",
  "Tracks",
  "Albums", 
  "Artists",
  "Explore",
  "Genres",
  "Folders",
  "Podcasts",
  "AI Features",
];

interface MusicHeaderProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function MusicHeader({ activeTab, onTabChange }: MusicHeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const { toggleAIAssist } = useApp();

  return (
    <header className="glass-card border-b border-card-border">
      {/* Top Bar */}
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center gap-4">
          <SidebarTrigger className="p-2 hover:bg-music-primary/10 rounded-lg transition-colors" />
          
          {/* Search */}
          <div className="relative flex items-center">
            <Search className="absolute left-3 w-4 h-4 text-foreground-muted" />
            <Input
              placeholder="Search music, playlists, or ask AI..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-96 pl-10 pr-12 glass border-music-primary/20 focus:border-music-primary bg-background-elevated"
            />
            <Button
              size="sm"
              variant="ghost"
              className="absolute right-1 p-2 text-music-primary hover:bg-music-primary/10"
            >
              <Mic className="w-4 h-4" />
            </Button>
          </div>

          {/* AI Quick Actions */}
          <Button
            variant="outline"
            size="sm"
            onClick={toggleAIAssist}
            className="gap-2 border-music-primary/30 text-music-primary hover:bg-music-primary/10"
          >
            <Sparkles className="w-4 h-4" />
            AI Assist
          </Button>
        </div>

        {/* Right Side */}
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" className="relative">
            <Bell className="w-5 h-5" />
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-music-primary rounded-full"></span>
          </Button>
          
          <Button variant="ghost" size="sm">
            <Settings className="w-5 h-5" />
          </Button>

          {/* User Profile */}
          <Button variant="ghost" className="gap-2 pl-2">
            <div className="w-8 h-8 rounded-full bg-gradient-primary flex items-center justify-center">
              <User className="w-4 h-4 text-white" />
            </div>
            <span className="text-sm font-medium">Music Lover</span>
            <ChevronDown className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="px-4 pb-4">
        <div className="flex items-center gap-2">
          <div className="flex gap-1 bg-background-elevated rounded-xl p-1 flex-1">
            {navigationTabs.map((tab) => (
              <button
                key={tab}
                onClick={() => onTabChange(tab)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                  activeTab === tab
                    ? "bg-music-primary text-white shadow-glow"
                    : "text-foreground-muted hover:text-music-primary hover:bg-music-primary/10"
                }`}
              >
                {tab}
                {tab === "AI Features" && (
                  <span className="ml-2 text-xs bg-music-primary/20 text-music-primary px-1.5 py-0.5 rounded-full">
                    NEW
                  </span>
                )}
              </button>
            ))}
          </div>
          
          {/* Menu Options */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-10 w-10 p-0">
                <MoreVertical className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuItem className="gap-2">
                <CheckSquare className="w-4 h-4" />
                Select Tracks
              </DropdownMenuItem>
              <DropdownMenuItem className="gap-2">
                <ArrowUpDown className="w-4 h-4" />
                Sort Library
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="gap-2">
                <Shuffle className="w-4 h-4" />
                Shuffle All
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      
      <AIAssistModal />
    </header>
  );
}