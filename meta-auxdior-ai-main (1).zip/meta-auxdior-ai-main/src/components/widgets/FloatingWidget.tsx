import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Play, Pause, SkipForward, Volume2, X, Music } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export function FloatingWidget() {
  const {
    isWidgetVisible,
    toggleWidget,
    currentTrack,
    isPlaying,
    togglePlay,
    nextTrack,
    volume,
    setVolume
  } = useApp();

  if (!isWidgetVisible) return null;

  return (
    <div className="fixed top-4 right-4 z-50 animate-scale-in">
      <Card className="glass-card bg-background/95 backdrop-blur-md border-music-primary/20 shadow-2xl">
        <CardContent className="p-4 w-80">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-primary/20 flex items-center justify-center">
                <Music className="w-4 h-4 text-music-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h4 className="font-medium text-sm truncate">{currentTrack?.title || 'No track'}</h4>
                <p className="text-xs text-foreground-muted truncate">{currentTrack?.artist || 'Unknown'}</p>
              </div>
            </div>
            <Button
              size="sm"
              variant="ghost"
              onClick={toggleWidget}
              className="w-8 h-8 p-0"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          <div className="flex items-center gap-2 mb-3">
            <Button
              size="sm"
              onClick={togglePlay}
              className="w-8 h-8 p-0"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </Button>
            <Button
              size="sm"
              variant="outline"
              onClick={nextTrack}
              className="w-8 h-8 p-0"
            >
              <SkipForward className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-2 flex-1">
              <Volume2 className="w-4 h-4 text-music-primary" />
              <Slider
                value={volume}
                onValueChange={setVolume}
                max={100}
                step={1}
                className="flex-1"
              />
            </div>
          </div>

          <div className="text-xs text-center text-foreground-muted">
            Mini Player • Meta-Auxdior.FM-35
          </div>
        </CardContent>
      </Card>
    </div>
  );
}