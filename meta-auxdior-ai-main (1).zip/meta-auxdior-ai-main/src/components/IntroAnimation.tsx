import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { SkipForward } from 'lucide-react';

interface IntroAnimationProps {
  onComplete: () => void;
}

export function IntroAnimation({ onComplete }: IntroAnimationProps) {
  const [step, setStep] = useState(0);
  const [showSkip, setShowSkip] = useState(false);

  useEffect(() => {
    const timers: NodeJS.Timeout[] = [];

    // Step 1: Nexus of Quality Sounds (5s total)
    timers.push(setTimeout(() => setStep(1), 500));
    
    // Step 2: Welcome Message (4s)
    timers.push(setTimeout(() => setStep(2), 5500));
    
    // Step 3: OPTISYNCORE (3s)
    timers.push(setTimeout(() => setStep(3), 9500));
    
    // Step 4: Soundwave Transition
    timers.push(setTimeout(() => setStep(4), 12500));
    
    // Complete animation
    timers.push(setTimeout(() => onComplete(), 14000));
    
    // Show skip button after 1s
    timers.push(setTimeout(() => setShowSkip(true), 1000));

    return () => {
      timers.forEach(timer => clearTimeout(timer));
    };
  }, [onComplete]);

  const handleSkip = () => {
    setStep(5);
    setTimeout(onComplete, 300);
  };

  // Generate soundwave bars for step 4
  const soundwaveBars = Array.from({ length: 50 }, (_, i) => {
    const delay = i * 0.05;
    const height = 20 + Math.sin(i * 0.3) * 40;
    
    return (
      <div
        key={i}
        className="soundwave-bar"
        style={{
          animationDelay: `${delay}s`,
          height: `${height}%`,
          left: `${(i / 50) * 100}%`
        }}
      />
    );
  });

  // Generate sparkle particles for step 3
  const sparkles = Array.from({ length: 12 }, (_, i) => (
    <div
      key={i}
      className="sparkle"
      style={{
        left: `${20 + Math.random() * 60}%`,
        top: `${30 + Math.random() * 40}%`,
        animationDelay: `${i * 0.2}s`
      }}
    />
  ));

  return (
    <div className={`intro-animation-container ${step === 5 ? 'fade-out' : ''}`}>
      {/* Step 1: Nexus of Quality Sounds */}
      {step === 1 && (
        <div className="intro-step step-1">
          <h1 className="step-1-text glow-neon">Nexus of Quality Sounds</h1>
        </div>
      )}

      {/* Step 2: Welcome Message */}
      {step === 2 && (
        <div className="intro-step step-2">
          <h2 className="step-2-text pulse-text">Welcome 2 Meta-Auxdior.FM-35</h2>
        </div>
      )}

      {/* Step 3: OPTISYNCORE */}
      {step === 3 && (
        <div className="intro-step step-3">
          <div className="sparkle-container">
            {sparkles}
          </div>
          <h1 className="step-3-text glow-trademark">OPTISYNCORE™</h1>
        </div>
      )}

      {/* Step 4: Soundwave Transition */}
      {step === 4 && (
        <div className="intro-step step-4">
          <div className="soundwave-container">
            {soundwaveBars}
          </div>
          <div className="soundwave-overlay"></div>
        </div>
      )}

      {/* Skip Button */}
      {showSkip && step < 4 && (
        <Button
          onClick={handleSkip}
          variant="ghost"
          className="skip-button animate-fade-in"
        >
          <SkipForward className="w-4 h-4 mr-2" />
          Tap to Skip
        </Button>
      )}
    </div>
  );
}