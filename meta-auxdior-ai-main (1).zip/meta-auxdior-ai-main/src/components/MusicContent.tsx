import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ExploreContent } from "./ExploreContent";
import { FoldersContent } from "./FoldersContent";
import {
  Play,
  Pause,
  Heart,
  MoreHorizontal,
  Music,
  Clock,
  User,
  Album,
  Mic,
  Sparkles,
  TrendingUp,
  Zap,
  Brain,
  Shuffle,
  Star,
  History,
  PlusCircle,
  BarChart3,
} from "lucide-react";

interface Track {
  id: string;
  title: string;
  artist: string;
  duration: string;
  isPlaying?: boolean;
  isLiked?: boolean;
  genre?: string;
  mood?: string;
}

interface MusicContentProps {
  activeTab: string;
}

const sampleTracks: Track[] = [
  { id: "1", title: "Midnight Reflections", artist: "AI Composer", duration: "4:23", genre: "Ambient", mood: "Calm" },
  { id: "2", title: "Digital Dreams", artist: "Synth Master", duration: "3:45", genre: "Electronic", mood: "Energetic" },
  { id: "3", title: "Ocean Waves", artist: "Nature Sounds AI", duration: "5:12", genre: "Ambient", mood: "Relaxing" },
  { id: "4", title: "City Lights", artist: "Urban Beat", duration: "3:28", genre: "Hip-Hop", mood: "Focused" },
  { id: "5", title: "Forest Whispers", artist: "Zen AI", duration: "6:15", genre: "Nature", mood: "Meditative" },
];

const aiFeatures = [
  {
    icon: Brain,
    title: "Smart Playlist Generator",
    description: "AI creates perfect playlists based on your mood and activity",
    badge: "Popular",
  },
  {
    icon: Sparkles,
    title: "Adaptive Equalizer",
    description: "Automatically adjusts audio settings for optimal sound quality",
    badge: "AI",
  },
  {
    icon: TrendingUp,
    title: "Predictive Recommendations",
    description: "Discover new music before you even know you'll love it",
    badge: "Smart",
  },
  {
    icon: Zap,
    title: "Instant Mood Analysis",
    description: "Analyzes your current mood and suggests matching music",
    badge: "Real-time",
  },
];

export function MusicContent({ activeTab }: MusicContentProps) {
  const [playingTrack, setPlayingTrack] = useState<string | null>(null);

  const handlePlayPause = (trackId: string) => {
    setPlayingTrack(playingTrack === trackId ? null : trackId);
  };

  const renderAIFeatures = () => (
    <div className="space-y-6">
      {/* AI Hero Section */}
      <div className="glass-card p-8 bg-gradient-hero rounded-2xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">AI Music Assistant</h2>
            <p className="text-white/80">Experience intelligent music discovery and personalization</p>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          <Button className="bg-white/20 hover:bg-white/30 text-white border-white/20 justify-start h-auto p-4">
            <Mic className="w-5 h-5 mr-3" />
            <div className="text-left">
              <div className="font-medium">Voice Commands</div>
              <div className="text-sm opacity-80">"Play relaxing jazz for studying"</div>
            </div>
          </Button>
          
          <Button className="bg-white/20 hover:bg-white/30 text-white border-white/20 justify-start h-auto p-4">
            <Shuffle className="w-5 h-5 mr-3" />
            <div className="text-left">
              <div className="font-medium">Smart Shuffle</div>
              <div className="text-sm opacity-80">AI-powered intelligent randomization</div>
            </div>
          </Button>
        </div>
      </div>

      {/* AI Features Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {aiFeatures.map((feature, index) => (
          <Card key={index} className="music-card p-6 cursor-pointer group">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center group-hover:scale-110 transition-transform">
                <feature.icon className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-semibold">{feature.title}</h3>
                  <span className="text-xs bg-music-primary/20 text-music-primary px-2 py-0.5 rounded-full">
                    {feature.badge}
                  </span>
                </div>
                <p className="text-sm text-foreground-muted">{feature.description}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderTracks = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">Your Music Library</h2>
          <p className="text-foreground-muted">3,247 tracks • 89 playlists</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2">
            <Sparkles className="w-4 h-4" />
            AI Organize
          </Button>
          <Button className="gap-2 bg-gradient-primary">
            <Play className="w-4 h-4" />
            Play All
          </Button>
        </div>
      </div>

      <div className="space-y-2">
        {sampleTracks.map((track, index) => (
          <Card key={track.id} className="p-4 hover:bg-card-elevated transition-colors group">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-gradient-primary flex items-center justify-center relative">
                <Music className="w-5 h-5 text-white" />
                <Button
                  size="sm"
                  className="absolute inset-0 w-full h-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"
                  onClick={() => handlePlayPause(track.id)}
                >
                  {playingTrack === track.id ? (
                    <Pause className="w-4 h-4 text-white" />
                  ) : (
                    <Play className="w-4 h-4 text-white" />
                  )}
                </Button>
              </div>

              <div className="flex-1 min-w-0">
                <h3 className="font-medium truncate">{track.title}</h3>
                <p className="text-sm text-foreground-muted truncate">{track.artist}</p>
                {track.mood && (
                  <div className="flex items-center gap-1 mt-1">
                    <span className="text-xs bg-music-accent/20 text-music-accent px-2 py-0.5 rounded-full">
                      {track.mood}
                    </span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                <span className="text-sm text-foreground-muted">{track.duration}</span>
                <Button variant="ghost" size="sm">
                  <Heart className="w-4 h-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderPlaylists = () => (
    <div className="space-y-6">
      {/* Favorite Categories Section */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        <Card className="music-card p-6 cursor-pointer group hover:bg-gradient-primary/10">
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-gradient-primary flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold text-lg mb-1">My Favorite</h3>
            <p className="text-sm text-foreground-muted">127 tracks</p>
          </div>
        </Card>

        <Card className="music-card p-6 cursor-pointer group hover:bg-gradient-primary/10">
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-music-accent flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <PlusCircle className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold text-lg mb-1">Recent Add</h3>
            <p className="text-sm text-foreground-muted">23 new tracks</p>
          </div>
        </Card>

        <Card className="music-card p-6 cursor-pointer group hover:bg-gradient-primary/10">
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-music-success flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <History className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold text-lg mb-1">Recent Play</h3>
            <p className="text-sm text-foreground-muted">Last 50 played</p>
          </div>
        </Card>

        <Card className="music-card p-6 cursor-pointer group hover:bg-gradient-primary/10">
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 rounded-2xl bg-music-warning flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
              <BarChart3 className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold text-lg mb-1">Most Play</h3>
            <p className="text-sm text-foreground-muted">Top 100 tracks</p>
          </div>
        </Card>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Your Playlists</h2>
          <p className="text-foreground-muted">89 playlists • 12 AI generated</p>
        </div>
        <Button className="gap-2 bg-gradient-primary">
          <Sparkles className="w-4 h-4" />
          Generate Playlist
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[
          { name: "Focus Flow", tracks: 24, aiGenerated: true, mood: "Productive" },
          { name: "Midnight Vibes", tracks: 18, aiGenerated: false, mood: "Chill" },
          { name: "Workout Energy", tracks: 32, aiGenerated: true, mood: "Energetic" },
          { name: "Study Sessions", tracks: 45, aiGenerated: true, mood: "Calm" },
          { name: "Road Trip", tracks: 28, aiGenerated: false, mood: "Adventure" },
          { name: "Sunday Morning", tracks: 16, aiGenerated: true, mood: "Peaceful" },
        ].map((playlist, index) => (
          <Card key={index} className="music-card p-6 cursor-pointer group">
            <div className="aspect-square rounded-xl bg-gradient-primary mb-4 flex items-center justify-center">
              <Album className="w-8 h-8 text-white" />
            </div>
            <h3 className="font-semibold mb-1">{playlist.name}</h3>
            <p className="text-sm text-foreground-muted mb-2">{playlist.tracks} tracks</p>
            <div className="flex items-center gap-2">
              <span className={`text-xs px-2 py-0.5 rounded-full ${
                playlist.aiGenerated 
                  ? "bg-music-primary/20 text-music-primary" 
                  : "bg-muted text-foreground-muted"
              }`}>
                {playlist.aiGenerated ? "AI Generated" : "Manual"}
              </span>
              <span className="text-xs bg-music-accent/20 text-music-accent px-2 py-0.5 rounded-full">
                {playlist.mood}
              </span>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case "AI Features":
        return renderAIFeatures();
      case "Tracks":
        return renderTracks();
      case "Playlists":
        return renderPlaylists();
      case "Explore":
        return <ExploreContent />;
      case "Folders":
        return <FoldersContent />;
      case "Albums":
        return (
          <div className="text-center py-20">
            <Album className="w-16 h-16 text-music-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Albums Coming Soon</h3>
            <p className="text-foreground-muted">AI-curated album collections will be available here</p>
          </div>
        );
      case "Artists":
        return (
          <div className="text-center py-20">
            <User className="w-16 h-16 text-music-primary mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">Artists Coming Soon</h3>
            <p className="text-foreground-muted">Discover your favorite artists and AI composers</p>
          </div>
        );
      default:
        return renderPlaylists();
    }
  };

  return (
    <div className="p-6 pb-32 animate-fade-in">
      {renderContent()}
    </div>
  );
}