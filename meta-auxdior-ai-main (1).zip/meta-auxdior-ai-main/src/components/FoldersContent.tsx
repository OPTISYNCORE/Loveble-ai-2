import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Folder, 
  FolderOpen, 
  Music, 
  Search, 
  Filter,
  Grid3X3,
  List,
  SortAsc,
  Plus,
  MoreVertical
} from "lucide-react";
import foldersWallpaper from "@/assets/folders-wallpaper.jpg";

export function FoldersContent() {
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [selectedFolder, setSelectedFolder] = useState<string | null>(null);

  const folders = [
    { 
      name: "My Music", 
      count: 1247, 
      type: "music", 
      lastModified: "2 hours ago",
      size: "8.5 GB"
    },
    { 
      name: "Playlists", 
      count: 89, 
      type: "playlist", 
      lastModified: "1 day ago",
      size: "2.1 GB"
    },
    { 
      name: "Downloaded", 
      count: 342, 
      type: "download", 
      lastModified: "3 hours ago",
      size: "3.2 GB"
    },
    { 
      name: "Favorites", 
      count: 156, 
      type: "favorite", 
      lastModified: "1 hour ago",
      size: "1.8 GB"
    },
    { 
      name: "Recent", 
      count: 45, 
      type: "recent", 
      lastModified: "Just now",
      size: "512 MB"
    },
    { 
      name: "Albums", 
      count: 234, 
      type: "album", 
      lastModified: "5 hours ago",
      size: "5.4 GB"
    },
  ];

  const filteredFolders = folders.filter(folder =>
    folder.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const getFolderIcon = (type: string, isSelected: boolean) => {
    return isSelected ? FolderOpen : Folder;
  };

  const getFolderColor = (type: string) => {
    switch (type) {
      case 'music': return 'text-blue-400';
      case 'playlist': return 'text-green-400';
      case 'download': return 'text-purple-400';
      case 'favorite': return 'text-red-400';
      case 'recent': return 'text-yellow-400';
      case 'album': return 'text-indigo-400';
      default: return 'text-music-primary';
    }
  };

  return (
    <div 
      className="min-h-screen bg-cover bg-center bg-no-repeat relative"
      style={{
        backgroundImage: `linear-gradient(rgba(23, 25, 35, 0.85), rgba(23, 25, 35, 0.85)), url(${foldersWallpaper})`
      }}
    >
      <div className="relative z-10 p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gradient mb-2">Folders</h1>
            <p className="text-foreground-muted">Organize your music collection</p>
          </div>
          <Button className="gap-2 bg-music-primary hover:bg-music-primary-glow">
            <Plus className="w-4 h-4" />
            New Folder
          </Button>
        </div>

        {/* Search and Filters */}
        <div className="glass-card p-4 mb-6">
          <div className="flex items-center gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 w-4 h-4 text-foreground-muted" />
              <Input
                placeholder="Search folders..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 glass border-music-primary/20 focus:border-music-primary"
              />
            </div>
            <Button variant="outline" size="sm" className="gap-2">
              <Filter className="w-4 h-4" />
              Filter
            </Button>
            <Button variant="outline" size="sm" className="gap-2">
              <SortAsc className="w-4 h-4" />
              Sort
            </Button>
            <div className="flex border border-card-border rounded-lg overflow-hidden">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="rounded-none"
              >
                <Grid3X3 className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="rounded-none"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Folders Grid/List */}
        <div className={`
          ${viewMode === 'grid' 
            ? 'grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6' 
            : 'space-y-4'
          }
        `}>
          {filteredFolders.map((folder) => {
            const FolderIcon = getFolderIcon(folder.type, selectedFolder === folder.name);
            const colorClass = getFolderColor(folder.type);
            
            return (
              <Card 
                key={folder.name}
                className={`glass-card cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-glow ${
                  selectedFolder === folder.name ? 'border-music-primary shadow-glow' : ''
                }`}
                onClick={() => setSelectedFolder(selectedFolder === folder.name ? null : folder.name)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <FolderIcon className={`w-8 h-8 ${colorClass}`} />
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </div>
                  <CardTitle className="text-lg">{folder.name}</CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Music className="w-4 h-4 text-music-primary" />
                      <span className="text-sm text-foreground-muted">
                        {folder.count} items
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-foreground-muted">
                      <span>{folder.size}</span>
                      <span>{folder.lastModified}</span>
                    </div>
                    <Badge 
                      variant="secondary" 
                      className="text-xs bg-music-primary/20 text-music-primary"
                    >
                      {folder.type}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Empty State */}
        {filteredFolders.length === 0 && (
          <div className="text-center py-12">
            <Folder className="w-16 h-16 text-foreground-muted mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No folders found</h3>
            <p className="text-foreground-muted mb-4">
              {searchQuery ? 'Try adjusting your search query' : 'Create your first folder to get started'}
            </p>
            <Button className="gap-2 bg-music-primary hover:bg-music-primary-glow">
              <Plus className="w-4 h-4" />
              Create Folder
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}