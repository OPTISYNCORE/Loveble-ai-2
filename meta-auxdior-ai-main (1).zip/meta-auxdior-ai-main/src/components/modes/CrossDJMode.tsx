import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Play, 
  Pause, 
  SkipForward, 
  SkipBack, 
  Volume2, 
  Repeat, 
  Shuffle,
  RotateCcw,
  X,
  Disc3
} from "lucide-react";
import { useState } from "react";

export function CrossDJMode() {
  const { 
    isDJModeActive, 
    setIsDJModeActive, 
    tracks, 
    currentTrack,
    isPlaying,
    togglePlay 
  } = useApp();
  
  const [deckATrack, setDeckATrack] = useState(tracks[0]);
  const [deckBTrack, setDeckBTrack] = useState(tracks[1] || tracks[0]);
  const [deckAPlaying, setDeckAPlaying] = useState(false);
  const [deckBPlaying, setDeckBPlaying] = useState(false);
  const [crossfader, setCrossfader] = useState([50]);
  const [deckAVolume, setDeckAVolume] = useState([75]);
  const [deckBVolume, setDeckBVolume] = useState([75]);
  const [deckAProgress, setDeckAProgress] = useState([30]);
  const [deckBProgress, setDeckBProgress] = useState([45]);
  const [bpmSync, setBpmSync] = useState(false);

  if (!isDJModeActive) return null;

  const Deck = ({ 
    side, 
    track, 
    isPlaying, 
    onPlayToggle, 
    volume, 
    setVolume, 
    progress, 
    setProgress,
    onTrackChange 
  }: {
    side: 'A' | 'B';
    track: any;
    isPlaying: boolean;
    onPlayToggle: () => void;
    volume: number[];
    setVolume: (value: number[]) => void;
    progress: number[];
    setProgress: (value: number[]) => void;
    onTrackChange: (track: any) => void;
  }) => (
    <Card className="glass-card flex-1">
      <CardContent className="p-6">
        {/* Deck Header */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-gradient">Deck {side}</h3>
          <div className="flex items-center gap-2">
            <Disc3 className={`w-6 h-6 ${isPlaying ? 'animate-spin text-music-primary' : 'text-foreground-muted'}`} />
            <span className="text-sm bg-music-primary/20 text-music-primary px-2 py-1 rounded-full">
              {isPlaying ? 'LIVE' : 'CUE'}
            </span>
          </div>
        </div>

        {/* Track Info */}
        <div className="mb-6">
          <div className="w-full h-32 rounded-lg bg-gradient-primary/20 flex items-center justify-center mb-3">
            <div className="text-6xl opacity-50">🎵</div>
          </div>
          <h4 className="font-bold truncate">{track?.title || `Track ${side}`}</h4>
          <p className="text-sm text-foreground-muted truncate">{track?.artist || 'Unknown Artist'}</p>
          <div className="flex items-center gap-3 mt-2">
            <span className="text-xs bg-music-success/20 text-music-success px-2 py-1 rounded-full">
              BPM: 128
            </span>
            <span className="text-xs text-foreground-muted">{track?.duration || '0:00'}</span>
          </div>
        </div>

        {/* Waveform */}
        <div className="mb-4">
          <div className="h-16 glass-card p-2 flex items-center justify-center bg-gradient-to-r from-music-primary/10 via-music-primary/30 to-music-primary/10 rounded-lg mb-2">
            <div className="flex items-center gap-0.5 w-full justify-center">
              {Array.from({ length: 80 }).map((_, i) => (
                <div
                  key={i}
                  className={`w-0.5 bg-music-primary/60 rounded-full ${
                    i <= (progress[0] / 100) * 80 ? 'bg-music-primary' : 'bg-music-primary/20'
                  }`}
                  style={{ height: `${Math.random() * 30 + 5}px` }}
                />
              ))}
            </div>
          </div>
          <Slider
            value={progress}
            onValueChange={setProgress}
            max={100}
            step={1}
            className="w-full"
          />
        </div>

        {/* Controls */}
        <div className="space-y-4">
          {/* Playback Controls */}
          <div className="flex items-center justify-center gap-3">
            <Button variant="outline" size="sm">
              <SkipBack className="w-4 h-4" />
            </Button>
            <Button
              onClick={onPlayToggle}
              className={`w-16 h-16 rounded-full ${isPlaying ? 'bg-music-danger' : 'bg-gradient-primary'}`}
            >
              {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
            </Button>
            <Button variant="outline" size="sm">
              <SkipForward className="w-4 h-4" />
            </Button>
          </div>

          {/* Loop & Effects */}
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="flex-1">
              <RotateCcw className="w-4 h-4 mr-1" />
              LOOP
            </Button>
            <Button variant="outline" size="sm" className="flex-1">
              <Repeat className="w-4 h-4 mr-1" />
              1/4
            </Button>
          </div>

          {/* Volume */}
          <div className="flex items-center gap-3">
            <Volume2 className="w-4 h-4 text-music-primary" />
            <Slider
              value={volume}
              onValueChange={setVolume}
              max={100}
              step={1}
              className="flex-1"
            />
            <span className="text-xs w-8 text-center">{volume[0]}</span>
          </div>
        </div>

        {/* Track Browser */}
        <div className="mt-4 pt-4 border-t border-card-border">
          <h5 className="text-sm font-semibold mb-2">Browser</h5>
          <div className="max-h-24 overflow-y-auto space-y-1">
            {tracks.slice(0, 3).map((t) => (
              <div
                key={t.id}
                onClick={() => onTrackChange(t)}
                className={`text-xs p-2 rounded cursor-pointer transition-colors ${
                  t.id === track?.id ? 'bg-music-primary/20' : 'hover:bg-music-primary/10'
                }`}
              >
                <div className="font-medium truncate">{t.title}</div>
                <div className="text-foreground-muted truncate">{t.artist}</div>
              </div>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="fixed inset-0 z-50 bg-background/98 backdrop-blur-md">
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-card-border">
          <div className="flex items-center gap-4">
            <Disc3 className="w-8 h-8 text-music-primary" />
            <div>
              <h1 className="text-2xl font-bold text-gradient">Cross-DJ Mode</h1>
              <p className="text-sm text-foreground-muted">Professional DJ Interface • Meta-Auxdior.FM-35</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              onClick={() => setBpmSync(!bpmSync)}
              className={bpmSync ? 'bg-music-primary/20 text-music-primary' : ''}
            >
              BPM SYNC {bpmSync ? 'ON' : 'OFF'}
            </Button>
            <Button
              onClick={() => setIsDJModeActive(false)}
              variant="outline"
              size="lg"
              className="gap-2"
            >
              <X className="w-5 h-5" />
              Exit DJ Mode
            </Button>
          </div>
        </div>

        {/* Main Interface */}
        <div className="flex-1 p-6 overflow-hidden">
          <div className="h-full flex gap-6">
            {/* Deck A */}
            <Deck
              side="A"
              track={deckATrack}
              isPlaying={deckAPlaying}
              onPlayToggle={() => setDeckAPlaying(!deckAPlaying)}
              volume={deckAVolume}
              setVolume={setDeckAVolume}
              progress={deckAProgress}
              setProgress={setDeckAProgress}
              onTrackChange={setDeckATrack}
            />

            {/* Center Mixer */}
            <div className="w-80">
              <Card className="glass-card h-full">
                <CardContent className="p-6 h-full flex flex-col">
                  {/* Crossfader */}
                  <div className="flex-1 flex flex-col justify-center">
                    <div className="text-center mb-6">
                      <h3 className="text-xl font-bold text-gradient mb-2">CROSSFADER</h3>
                      <div className="flex justify-between text-sm text-foreground-muted mb-4">
                        <span>DECK A</span>
                        <span>DECK B</span>
                      </div>
                      <Slider
                        value={crossfader}
                        onValueChange={setCrossfader}
                        max={100}
                        step={1}
                        className="w-full mb-4"
                      />
                      <div className="text-center text-lg font-bold text-music-primary">
                        {crossfader[0] < 40 ? 'A' : crossfader[0] > 60 ? 'B' : 'CENTER'}
                      </div>
                    </div>

                    {/* Master Controls */}
                    <div className="space-y-4">
                      <div className="text-center">
                        <h4 className="font-semibold mb-3">MASTER OUTPUT</h4>
                        <div className="flex items-center gap-3 mb-4">
                          <Volume2 className="w-4 h-4" />
                          <Slider
                            value={[80]}
                            max={100}
                            step={1}
                            className="flex-1"
                          />
                          <span className="text-xs w-8">80</span>
                        </div>
                      </div>

                      {/* Effects */}
                      <div className="grid grid-cols-2 gap-2">
                        <Button variant="outline" size="sm">FILTER</Button>
                        <Button variant="outline" size="sm">REVERB</Button>
                        <Button variant="outline" size="sm">FLANGER</Button>
                        <Button variant="outline" size="sm">DELAY</Button>
                      </div>
                    </div>
                  </div>

                  {/* OPTISYNCORE Branding */}
                  <div className="mt-auto pt-4 border-t border-card-border text-center">
                    <div className="text-xs text-foreground-muted/60">
                      Powered by OPTISYNCORE™
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Deck B */}
            <Deck
              side="B"
              track={deckBTrack}
              isPlaying={deckBPlaying}
              onPlayToggle={() => setDeckBPlaying(!deckBPlaying)}
              volume={deckBVolume}
              setVolume={setDeckBVolume}
              progress={deckBProgress}
              setProgress={setDeckBProgress}
              onTrackChange={setDeckBTrack}
            />
          </div>
        </div>
      </div>
    </div>
  );
}