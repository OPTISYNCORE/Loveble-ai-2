import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useApp } from "@/contexts/AppContext";
import { Lock, Unlock, Eye, EyeOff } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export function HiddenModeModal() {
  const { isHiddenMode, toggleHiddenMode } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [pin, setPin] = useState('');
  const [showPin, setShowPin] = useState(false);
  const { toast } = useToast();

  const handleToggleHiddenMode = () => {
    if (isHiddenMode) {
      // Exit hidden mode
      toggleHiddenMode();
      setIsOpen(false);
      toast({
        title: "Hidden Mode Disabled",
        description: "All tracks and folders are now visible.",
      });
    } else {
      // Enter hidden mode with PIN
      if (pin === '1234') {
        toggleHiddenMode(pin);
        setIsOpen(false);
        setPin('');
        toast({
          title: "Hidden Mode Activated",
          description: "Sensitive content is now hidden.",
        });
      } else {
        toast({
          title: "Invalid PIN",
          description: "Please enter the correct PIN.",
          variant: "destructive",
        });
      }
    }
  };

  return (
    <>
      <Button
        variant="ghost"
        onClick={() => setIsOpen(true)}
        className="w-full justify-start gap-3 transition-all duration-300 hover:bg-music-primary/10"
      >
        {isHiddenMode ? <Unlock className="w-5 h-5 text-music-primary" /> : <Lock className="w-5 h-5 text-music-primary" />}
        <span>Hidden Mode</span>
        {isHiddenMode && (
          <span className="ml-auto text-xs bg-music-warning/20 text-music-warning px-2 py-0.5 rounded-full font-medium">
            ON
          </span>
        )}
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="glass-card max-w-md">
          <DialogHeader>
            <DialogTitle className="text-gradient flex items-center gap-2">
              <Lock className="w-5 h-5" />
              {isHiddenMode ? 'Exit Hidden Mode' : 'Enable Hidden Mode'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {!isHiddenMode ? (
              <>
                <p className="text-sm text-foreground-muted">
                  Hidden Mode will lock sensitive tracks and folders behind a PIN.
                </p>
                
                <div className="space-y-2">
                  <Label htmlFor="pin">Enter PIN</Label>
                  <div className="relative">
                    <Input
                      id="pin"
                      type={showPin ? "text" : "password"}
                      value={pin}
                      onChange={(e) => setPin(e.target.value)}
                      placeholder="Enter 4-digit PIN"
                      maxLength={4}
                      className="pr-10"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setShowPin(!showPin)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6 p-0"
                    >
                      {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>

                <div className="p-3 bg-music-warning/10 border border-music-warning/20 rounded-lg">
                  <p className="text-xs text-music-warning">
                    <strong>Demo PIN:</strong> 1234 (for testing purposes)
                  </p>
                </div>
              </>
            ) : (
              <p className="text-sm text-foreground-muted">
                Are you sure you want to exit Hidden Mode? All hidden content will become visible.
              </p>
            )}

            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={() => setIsOpen(false)} className="flex-1">
                Cancel
              </Button>
              <Button onClick={handleToggleHiddenMode} className="flex-1 gap-2">
                {isHiddenMode ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
                {isHiddenMode ? 'Exit' : 'Enable'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}