import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { Play, Pause, SkipForward, SkipBack, Mic, Car, X } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

export function DriveMode() {
  const {
    isDriveModeActive,
    toggleDriveMode,
    currentTrack,
    isPlaying,
    togglePlay,
    nextTrack,
    previousTrack
  } = useApp();

  if (!isDriveModeActive) return null;

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-md flex items-center justify-center">
      <div className="max-w-2xl w-full p-8">
        <Card className="glass-card bg-gradient-card border-music-primary/20">
          <CardContent className="p-8 text-center">
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-3">
                <Car className="w-8 h-8 text-music-primary" />
                <h1 className="text-2xl font-bold text-gradient">Drive Mode</h1>
              </div>
              <Button
                onClick={toggleDriveMode}
                variant="outline"
                size="lg"
                className="gap-2"
              >
                <X className="w-5 h-5" />
                Exit
              </Button>
            </div>

            {/* Current Track */}
            <div className="mb-8">
              <div className="w-32 h-32 mx-auto mb-4 rounded-2xl bg-gradient-primary/20 flex items-center justify-center">
                <div className="text-4xl">🎵</div>
              </div>
              <h2 className="text-xl font-bold mb-2">{currentTrack?.title || 'No Track'}</h2>
              <p className="text-lg text-foreground-muted">{currentTrack?.artist || 'Unknown Artist'}</p>
            </div>

            {/* Large Controls */}
            <div className="flex items-center justify-center gap-6 mb-8">
              <Button
                onClick={previousTrack}
                size="lg"
                variant="outline"
                className="w-16 h-16 rounded-full p-0"
              >
                <SkipBack className="w-8 h-8" />
              </Button>
              
              <Button
                onClick={togglePlay}
                size="lg"
                className="w-20 h-20 rounded-full p-0 bg-gradient-primary"
              >
                {isPlaying ? <Pause className="w-10 h-10" /> : <Play className="w-10 h-10" />}
              </Button>
              
              <Button
                onClick={nextTrack}
                size="lg"
                variant="outline"
                className="w-16 h-16 rounded-full p-0"
              >
                <SkipForward className="w-8 h-8" />
              </Button>
            </div>

            {/* Voice Control */}
            <Button
              size="lg"
              variant="outline"
              className="gap-3 px-8 py-4 text-lg"
            >
              <Mic className="w-6 h-6" />
              Voice Command (Coming Soon)
            </Button>

            <div className="mt-8 text-sm text-foreground-muted">
              <p>Safe driving mode with large controls</p>
              <p>Voice commands will be available soon</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}