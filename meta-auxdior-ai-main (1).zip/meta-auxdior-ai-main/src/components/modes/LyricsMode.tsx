import { useApp } from "@/contexts/AppContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Music2, X, Mic, Volume2, Type } from "lucide-react";
import { useState } from "react";

export function LyricsMode() {
  const { isLyricsModeActive, toggleLyricsMode, currentTrack } = useApp();
  const [fontSize, setFontSize] = useState('text-lg');
  
  if (!isLyricsModeActive) return null;

  // Placeholder lyrics - in real implementation, these would come from API
  const mockLyrics = [
    { time: "0:15", text: "Lost in the neon lights of the city tonight" },
    { time: "0:22", text: "Chasing dreams that feel so far away" },
    { time: "0:30", text: "But I won't give up, I'll find my way" },
    { time: "0:37", text: "Through the shadows and the pain" },
    { time: "0:45", text: "" },
    { time: "0:48", text: "We're dancing on the edge of time" },
    { time: "0:55", text: "With hearts that beat in perfect rhyme" },
    { time: "1:03", text: "The music flows through our souls" },
    { time: "1:10", text: "As we lose all control" },
    { time: "1:18", text: "" },
    { time: "1:20", text: "[Instrumental Break]" },
    { time: "1:45", text: "" },
    { time: "1:48", text: "Electric pulse beneath my skin" },
    { time: "1:55", text: "Feel the rhythm pulling me in" },
  ];

  return (
    <div className="fixed inset-0 z-40 bg-background/95 backdrop-blur-md">
      <div className="h-full flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-card-border">
          <div className="flex items-center gap-4">
            <Music2 className="w-8 h-8 text-music-primary" />
            <div>
              <h1 className="text-2xl font-bold text-gradient">Lyrics Mode</h1>
              <p className="text-sm text-foreground-muted">
                Real-time synchronized lyrics • {currentTrack?.title || 'No track'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              <Type className="w-4 h-4 text-music-primary" />
              <select 
                value={fontSize}
                onChange={(e) => setFontSize(e.target.value)}
                className="bg-transparent border border-card-border rounded px-2 py-1 text-sm"
              >
                <option value="text-sm">Small</option>
                <option value="text-lg">Medium</option>
                <option value="text-xl">Large</option>
                <option value="text-2xl">Extra Large</option>
              </select>
            </div>
            
            <Button
              onClick={toggleLyricsMode}
              variant="outline"
              size="lg"
              className="gap-2"
            >
              <X className="w-5 h-5" />
              Exit Lyrics
            </Button>
          </div>
        </div>

        {/* Lyrics Content */}
        <div className="flex-1 overflow-hidden">
          <div className="h-full flex">
            {/* Main Lyrics Display */}
            <div className="flex-1 p-8">
              <Card className="glass-card h-full">
                <CardContent className="p-8 h-full overflow-y-auto">
                  <div className="max-w-3xl mx-auto space-y-6">
                    {/* Current Track Info */}
                    <div className="text-center mb-8">
                      <h2 className="text-3xl font-bold mb-2">{currentTrack?.title || 'No Track Playing'}</h2>
                      <p className="text-xl text-foreground-muted">{currentTrack?.artist || 'Unknown Artist'}</p>
                      <p className="text-sm text-foreground-muted mt-2">{currentTrack?.album || 'Unknown Album'}</p>
                    </div>

                    {/* Lyrics */}
                    <div className="space-y-4">
                      {mockLyrics.map((line, index) => (
                        <div
                          key={index}
                          className={`flex items-center gap-4 p-3 rounded-lg transition-all duration-300 ${
                            index === 5 // Mock current line
                              ? 'bg-music-primary/20 border border-music-primary/30 scale-105'
                              : index < 5
                              ? 'text-foreground-muted'
                              : ''
                          }`}
                        >
                          <span className="text-xs text-music-primary font-mono min-w-fit">
                            {line.time}
                          </span>
                          <p className={`${fontSize} leading-relaxed ${line.text === '' ? 'h-4' : ''} ${
                            line.text.includes('[') ? 'italic text-music-primary' : ''
                          }`}>
                            {line.text}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="w-80 p-6 border-l border-card-border">
              <div className="space-y-4">
                {/* Karaoke Mode */}
                <Card className="glass-card">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <Mic className="w-5 h-5 text-music-primary" />
                      <h3 className="font-semibold">Karaoke Mode</h3>
                    </div>
                    <p className="text-sm text-foreground-muted mb-3">
                      Enable microphone for sing-along
                    </p>
                    <Button variant="outline" className="w-full" disabled>
                      <Mic className="w-4 h-4 mr-2" />
                      Enable Mic (Coming Soon)
                    </Button>
                  </CardContent>
                </Card>

                {/* Vocal Controls */}
                <Card className="glass-card">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <Volume2 className="w-5 h-5 text-music-primary" />
                      <h3 className="font-semibold">Vocal Controls</h3>
                    </div>
                    <div className="space-y-3">
                      <Button variant="outline" className="w-full text-sm" disabled>
                        Reduce Vocals
                      </Button>
                      <Button variant="outline" className="w-full text-sm" disabled>
                        Isolate Instrumentals
                      </Button>
                      <Button variant="outline" className="w-full text-sm" disabled>
                        Pitch Adjust
                      </Button>
                    </div>
                    <p className="text-xs text-foreground-muted mt-2">
                      AI vocal separation coming soon
                    </p>
                  </CardContent>
                </Card>

                {/* Lyrics Info */}
                <Card className="glass-card">
                  <CardContent className="p-4">
                    <h3 className="font-semibold mb-3">Lyrics Info</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-foreground-muted">Source:</span>
                        <span>AI Generated</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-foreground-muted">Language:</span>
                        <span>English</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-foreground-muted">Sync:</span>
                        <span className="text-music-success">Auto</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* OPTISYNCORE Branding */}
                <div className="text-center pt-4 border-t border-card-border">
                  <div className="text-xs text-foreground-muted/60">
                    Lyrics powered by OPTISYNCORE™
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}