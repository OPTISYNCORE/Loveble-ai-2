import { useState } from "react";
import { SidebarProvider } from "@/components/ui/sidebar";
import { AppProvider, useAppContext } from "@/contexts/AppContext";
import { IntroAnimation } from "./IntroAnimation";
import { MusicSidebar } from "./MusicSidebar";
import { MusicHeader } from "./MusicHeader";
import { MusicContent } from "./MusicContent";
import { MusicPlayer } from "./MusicPlayer";
import { FloatingWidget } from "./widgets/FloatingWidget";
import { DriveMode } from "./modes/DriveMode";
import { CrossDJMode } from "./modes/CrossDJMode";
import { HiddenModeModal } from "./modes/HiddenMode";
import { LyricsMode } from "./modes/LyricsMode";

function MusicAppContent() {
  const [activeTab, setActiveTab] = useState("Playlists");
  const { introCompleted, setIntroCompleted } = useAppContext();

  if (!introCompleted) {
    return <IntroAnimation onComplete={() => setIntroCompleted(true)} />;
  }

  return (
    <SidebarProvider defaultOpen={true}>
      <div className="min-h-screen flex w-full bg-background">
        <MusicSidebar />
        
        <div className="flex-1 flex flex-col">
          <MusicHeader activeTab={activeTab} onTabChange={setActiveTab} />
          
          <main className="flex-1 overflow-auto">
            <MusicContent activeTab={activeTab} />
          </main>
        </div>
        
        <MusicPlayer />
        <FloatingWidget />
        <DriveMode />
        <CrossDJMode />
        <LyricsMode />
        <HiddenModeModal />
      </div>
    </SidebarProvider>
  );
}

export function MusicApp() {
  return (
    <AppProvider>
      <MusicAppContent />
    </AppProvider>
  );
}