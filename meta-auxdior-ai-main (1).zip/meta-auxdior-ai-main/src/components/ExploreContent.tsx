import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  TrendingUp,
  Globe,
  Music,
  Play,
  Heart,
  Clock,
  Users,
  Star,
  Sparkles,
  RefreshCw,
  Filter,
} from "lucide-react";

interface Genre {
  id: string;
  name: string;
  description: string;
  popularity: number;
  trending: boolean;
  trackCount: number;
  listeners: string;
  color: string;
}

interface TrendingTrack {
  id: string;
  title: string;
  artist: string;
  genre: string;
  country: string;
  plays: string;
  duration: string;
}

const latestGenres: Genre[] = [
  {
    id: "1",
    name: "Synthwave Revival",
    description: "80s-inspired electronic music making a comeback",
    popularity: 95,
    trending: true,
    trackCount: 12420,
    listeners: "2.3M",
    color: "from-pink-500 to-purple-600"
  },
  {
    id: "2", 
    name: "Afro-Jazz Fusion",
    description: "Modern jazz with African rhythms and instruments",
    popularity: 88,
    trending: true,
    trackCount: 8750,
    listeners: "1.8M",
    color: "from-orange-500 to-red-600"
  },
  {
    id: "3",
    name: "Digital Minimalism",
    description: "Stripped-down electronic compositions",
    popularity: 82,
    trending: false,
    trackCount: 5630,
    listeners: "1.2M",
    color: "from-blue-500 to-cyan-600"
  },
  {
    id: "4",
    name: "Neo-Soul Ambient",
    description: "Atmospheric soul music with modern production",
    popularity: 76,
    trending: true,
    trackCount: 9820,
    listeners: "1.9M",
    color: "from-green-500 to-emerald-600"
  },
  {
    id: "5",
    name: "Psychedelic Trap",
    description: "Hip-hop beats with psychedelic soundscapes",
    popularity: 91,
    trending: true,
    trackCount: 15670,
    listeners: "3.1M",
    color: "from-purple-500 to-indigo-600"
  },
  {
    id: "6",
    name: "Arctic Folk",
    description: "Nordic-inspired acoustic compositions",
    popularity: 68,
    trending: false,
    trackCount: 4120,
    listeners: "890K",
    color: "from-slate-500 to-blue-600"
  }
];

const globalTrending: TrendingTrack[] = [
  {
    id: "1",
    title: "Neon Dreams",
    artist: "Cyber Pulse",
    genre: "Synthwave Revival",
    country: "🇺🇸 USA",
    plays: "14.2M",
    duration: "4:12"
  },
  {
    id: "2",
    title: "Lagos Nights",
    artist: "Kemi Okafor",
    genre: "Afro-Jazz Fusion",
    country: "🇳🇬 Nigeria", 
    plays: "8.7M",
    duration: "5:23"
  },
  {
    id: "3",
    title: "Void State",
    artist: "Min.Tech",
    genre: "Digital Minimalism",
    country: "🇯🇵 Japan",
    plays: "6.1M",
    duration: "3:45"
  },
  {
    id: "4",
    title: "Soul Drift",
    artist: "Maya Rivers",
    genre: "Neo-Soul Ambient",
    country: "🇬🇧 UK",
    plays: "11.4M",
    duration: "6:18"
  }
];

export function ExploreContent() {
  const [playingTrack, setPlayingTrack] = useState<string | null>(null);
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);

  const handlePlayPause = (trackId: string) => {
    setPlayingTrack(playingTrack === trackId ? null : trackId);
  };

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="glass-card p-8 bg-gradient-hero rounded-2xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center">
              <Globe className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Explore Music Worldwide</h1>
              <p className="text-white/80 text-lg">Discover the latest genres and trending sounds from around the globe</p>
            </div>
          </div>
          <Button className="bg-white/20 hover:bg-white/30 text-white border-white/20 gap-2">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </Button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-white/10 border-white/20 p-4 text-center">
            <TrendingUp className="w-8 h-8 text-white mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">127</div>
            <div className="text-white/80 text-sm">New Genres This Week</div>
          </Card>
          
          <Card className="bg-white/10 border-white/20 p-4 text-center">
            <Users className="w-8 h-8 text-white mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">45.2M</div>
            <div className="text-white/80 text-sm">Global Listeners</div>
          </Card>
          
          <Card className="bg-white/10 border-white/20 p-4 text-center">
            <Music className="w-8 h-8 text-white mx-auto mb-2" />
            <div className="text-2xl font-bold text-white">2.8K</div>
            <div className="text-white/80 text-sm">Tracks Added Today</div>
          </Card>
        </div>
      </div>

      {/* Latest Genres Section */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">Trending Genres</h2>
            <p className="text-foreground-muted">Latest music genres gaining popularity worldwide</p>
          </div>
          <Button variant="outline" className="gap-2">
            <Filter className="w-4 h-4" />
            Filter
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {latestGenres.map((genre) => (
            <Card 
              key={genre.id} 
              className={`music-card p-6 cursor-pointer group transition-all duration-300 ${
                selectedGenre === genre.id ? "ring-2 ring-music-primary" : ""
              }`}
              onClick={() => setSelectedGenre(selectedGenre === genre.id ? null : genre.id)}
            >
              <div className={`w-full h-32 rounded-xl bg-gradient-to-br ${genre.color} mb-4 flex items-center justify-center group-hover:scale-105 transition-transform`}>
                <Music className="w-12 h-12 text-white" />
              </div>
              
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-bold text-lg">{genre.name}</h3>
                {genre.trending && (
                  <Badge className="bg-music-primary/20 text-music-primary border-music-primary/30">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    Trending
                  </Badge>
                )}
              </div>
              
              <p className="text-sm text-foreground-muted mb-4">{genre.description}</p>
              
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-foreground-muted">Popularity</span>
                  <span className="font-semibold">{genre.popularity}%</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div 
                    className="bg-gradient-primary h-2 rounded-full transition-all duration-500"
                    style={{ width: `${genre.popularity}%` }}
                  />
                </div>
                
                <div className="flex justify-between text-sm">
                  <div className="flex items-center gap-1">
                    <Music className="w-3 h-3" />
                    <span>{genre.trackCount.toLocaleString()}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    <span>{genre.listeners}</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Global Trending Tracks */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">Global Trending Now</h2>
            <p className="text-foreground-muted">Most popular tracks across different genres and countries</p>
          </div>
          <Button className="gap-2 bg-gradient-primary">
            <Sparkles className="w-4 h-4" />
            AI Discover
          </Button>
        </div>

        <div className="space-y-3">
          {globalTrending.map((track, index) => (
            <Card key={track.id} className="p-4 hover:bg-card-elevated transition-colors group">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-3">
                  <span className="text-xl font-bold text-music-primary w-6">
                    #{index + 1}
                  </span>
                  <div className="w-12 h-12 rounded-lg bg-gradient-primary flex items-center justify-center relative">
                    <Music className="w-5 h-5 text-white" />
                    <Button
                      size="sm"
                      className="absolute inset-0 w-full h-full bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg"
                      onClick={() => handlePlayPause(track.id)}
                    >
                      <Play className="w-4 h-4 text-white" />
                    </Button>
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold truncate">{track.title}</h3>
                  <p className="text-sm text-foreground-muted truncate">{track.artist}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="secondary" className="text-xs">
                      {track.genre}
                    </Badge>
                    <span className="text-xs text-foreground-muted">{track.country}</span>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-sm text-foreground-muted">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4" />
                    <span>{track.plays}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{track.duration}</span>
                  </div>
                  <Button variant="ghost" size="sm">
                    <Heart className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}