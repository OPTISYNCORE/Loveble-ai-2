import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useApp } from "@/contexts/AppContext";
import { Timer, Play } from "lucide-react";
import { useEffect, useState } from "react";

const timerOptions = [15, 30, 60, 90, 120];

export function SleepTimerModal() {
  const { sleepTimer, setSleepTimer, isSleepTimerActive } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(0);

  useEffect(() => {
    if (isSleepTimerActive && sleepTimer > 0) {
      setTimeRemaining(sleepTimer * 60); // Convert minutes to seconds
      const interval = setInterval(() => {
        setTimeRemaining(prev => {
          if (prev <= 1) {
            setSleepTimer(0); // This will stop the timer
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isSleepTimerActive, sleepTimer, setSleepTimer]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSetTimer = (minutes: number) => {
    setSleepTimer(minutes);
    setIsOpen(false);
  };

  return (
    <>
      <Button
        variant="ghost"
        onClick={() => setIsOpen(true)}
        className="w-full justify-start gap-3 transition-all duration-300 hover:bg-music-primary/10"
      >
        <Timer className="w-5 h-5 text-music-primary" />
        <span>Sleep Timer</span>
        {isSleepTimerActive && (
          <span className="ml-auto text-music-primary text-sm">
            {formatTime(timeRemaining)}
          </span>
        )}
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="glass-card max-w-md">
          <DialogHeader>
            <DialogTitle className="text-gradient flex items-center gap-2">
              <Timer className="w-5 h-5" />
              Sleep Timer
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-foreground-muted">
              Set a timer to automatically stop playback after the selected time.
            </p>

            <div className="grid grid-cols-2 gap-3">
              {timerOptions.map((minutes) => (
                <Button
                  key={minutes}
                  variant="outline"
                  onClick={() => handleSetTimer(minutes)}
                  className="h-12 flex flex-col items-center gap-1"
                >
                  <span className="font-semibold">{minutes}</span>
                  <span className="text-xs">minutes</span>
                </Button>
              ))}
            </div>

            {isSleepTimerActive && (
              <div className="glass-card p-4 bg-music-primary/10 border border-music-primary/20">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Play className="w-4 h-4 text-music-primary" />
                    <span className="text-sm font-medium">Timer Active</span>
                  </div>
                  <span className="font-mono text-lg text-music-primary">
                    {formatTime(timeRemaining)}
                  </span>
                </div>
                <Button
                  variant="outline"
                  onClick={() => setSleepTimer(0)}
                  className="w-full mt-3"
                >
                  Cancel Timer
                </Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}