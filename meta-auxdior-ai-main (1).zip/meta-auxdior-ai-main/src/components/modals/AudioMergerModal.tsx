import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useApp } from "@/contexts/AppContext";
import { useState } from "react";
import { Merge, Play, Pause, Download, X, Plus } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export function AudioMergerModal() {
  const { tracks } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTracks, setSelectedTracks] = useState<string[]>([]);
  const [crossfadeDuration, setCrossfadeDuration] = useState([3]);
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleAddTrack = (trackId: string) => {
    if (!selectedTracks.includes(trackId)) {
      setSelectedTracks(prev => [...prev, trackId]);
    }
  };

  const handleRemoveTrack = (trackId: string) => {
    setSelectedTracks(prev => prev.filter(id => id !== trackId));
  };

  const handleMerge = async () => {
    if (selectedTracks.length < 2) {
      toast({
        title: "Select Tracks",
        description: "Please select at least 2 tracks to merge",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    
    // Placeholder for actual merging logic
    setTimeout(() => {
      setIsProcessing(false);
      toast({
        title: "Merge Complete!",
        description: `Successfully merged ${selectedTracks.length} tracks with ${crossfadeDuration[0]}s crossfade`,
      });
      setSelectedTracks([]);
      setIsOpen(false);
    }, 3000);
  };

  return (
    <>
      <Button
        variant="ghost"
        onClick={() => setIsOpen(true)}
        className="w-full justify-start gap-3 transition-all duration-300 hover:bg-music-primary/10"
      >
        <Merge className="w-5 h-5 text-music-primary" />
        <span>Audio Merger</span>
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="glass-card max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-gradient flex items-center gap-2">
              <Merge className="w-5 h-5" />
              Audio Merger
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Available Tracks */}
            <div>
              <h3 className="font-semibold mb-3">Available Tracks</h3>
              <div className="grid grid-cols-1 gap-2 max-h-40 overflow-y-auto">
                {tracks.map((track) => (
                  <div key={track.id} className="flex items-center justify-between p-3 glass-card">
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{track.title}</p>
                      <p className="text-sm text-foreground-muted truncate">{track.artist}</p>
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleAddTrack(track.id)}
                      disabled={selectedTracks.includes(track.id)}
                      variant={selectedTracks.includes(track.id) ? "secondary" : "outline"}
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            {/* Selected Tracks */}
            <div>
              <h3 className="font-semibold mb-3">Merge Queue ({selectedTracks.length})</h3>
              <div className="space-y-2 min-h-[100px]">
                {selectedTracks.length === 0 ? (
                  <div className="flex items-center justify-center h-20 text-foreground-muted border-2 border-dashed border-card-border rounded-lg">
                    Add tracks to merge
                  </div>
                ) : (
                  selectedTracks.map((trackId, index) => {
                    const track = tracks.find(t => t.id === trackId);
                    return (
                      <Card key={trackId} className="glass-card">
                        <CardContent className="p-3 flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <span className="w-6 h-6 rounded-full bg-music-primary text-white text-sm flex items-center justify-center">
                              {index + 1}
                            </span>
                            <div>
                              <p className="font-medium">{track?.title}</p>
                              <p className="text-sm text-foreground-muted">{track?.artist}</p>
                            </div>
                          </div>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => handleRemoveTrack(trackId)}
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })
                )}
              </div>
            </div>

            {/* Crossfade Settings */}
            <div>
              <h3 className="font-semibold mb-3">Crossfade Duration</h3>
              <div className="flex items-center gap-4">
                <Slider
                  value={crossfadeDuration}
                  onValueChange={setCrossfadeDuration}
                  max={10}
                  min={0}
                  step={0.5}
                  className="flex-1"
                />
                <span className="text-sm font-medium min-w-fit">
                  {crossfadeDuration[0]}s
                </span>
              </div>
            </div>

            {/* Merge Button */}
            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={() => setIsOpen(false)} className="flex-1">
                Cancel
              </Button>
              <Button 
                onClick={handleMerge} 
                disabled={selectedTracks.length < 2 || isProcessing}
                className="flex-1 gap-2"
              >
                {isProcessing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Merging...
                  </>
                ) : (
                  <>
                    <Download className="w-4 h-4" />
                    Merge Tracks
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}