import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { SidebarMenuButton } from "@/components/ui/sidebar";
import { Cloud, CloudOff, HardDrive, Droplets, CheckCircle, AlertCircle } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import { useToast } from "@/hooks/use-toast";
import { useSidebar } from "@/components/ui/sidebar";

export function CloudSyncModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [autoSync, setAutoSync] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [isConnecting, setIsConnecting] = useState(false);
  const [connectedServices, setConnectedServices] = useState<string[]>([]);
  const { toast } = useToast();
  const { state } = useSidebar();
  const collapsed = state === "collapsed";

  const cloudServices = [
    {
      id: "google-drive",
      name: "Google Drive",
      icon: HardDrive,
      description: "Sync with Google Drive",
      storage: "15 GB free"
    },
    {
      id: "dropbox",
      name: "Dropbox",
      icon: Droplets,
      description: "Sync with Dropbox",
      storage: "2 GB free"
    },
    {
      id: "onedrive",
      name: "OneDrive",
      icon: HardDrive,
      description: "Sync with Microsoft OneDrive",
      storage: "5 GB free"
    }
  ];

  const handleConnectService = async (serviceId: string) => {
    setIsConnecting(true);
    
    // Simulate OAuth connection process
    setTimeout(() => {
      setConnectedServices(prev => [...prev, serviceId]);
      setIsConnecting(false);
      toast({
        title: "Connected Successfully",
        description: `${cloudServices.find(s => s.id === serviceId)?.name} is now connected`,
      });
    }, 2000);
  };

  const handleDisconnectService = (serviceId: string) => {
    setConnectedServices(prev => prev.filter(id => id !== serviceId));
    toast({
      title: "Disconnected",
      description: `${cloudServices.find(s => s.id === serviceId)?.name} has been disconnected`,
    });
  };

  const handleSyncNow = () => {
    if (connectedServices.length === 0) {
      toast({
        title: "No Services Connected",
        description: "Please connect a cloud service first",
        variant: "destructive",
      });
      return;
    }

    // Simulate sync process
    let progress = 0;
    const interval = setInterval(() => {
      progress += 10;
      setSyncProgress(progress);
      
      if (progress >= 100) {
        clearInterval(interval);
        toast({
          title: "Sync Complete",
          description: "Your library has been backed up successfully",
        });
        setTimeout(() => setSyncProgress(0), 2000);
      }
    }, 200);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <SidebarMenuButton
          className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
          tooltip={collapsed ? "Cloud Sync" : undefined}
        >
          <Cloud className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
          {!collapsed && (
            <div className="flex items-center justify-between w-full">
              <span className="font-medium">Cloud Sync</span>
              <div className="flex items-center gap-1">
                {connectedServices.length > 0 && (
                  <CheckCircle className="w-3 h-3 text-music-success" />
                )}
                <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-music-primary/20 text-music-primary">
                  premium
                </span>
              </div>
            </div>
          )}
        </SidebarMenuButton>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-[600px] glass-card">
        <DialogHeader>
          <DialogTitle className="text-gradient flex items-center gap-2">
            <Cloud className="w-5 h-5" />
            Cloud Library Sync
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Auto Sync Setting */}
          <div className="glass-card p-4 bg-gradient-card rounded-xl">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium">Auto Sync</h3>
                <p className="text-sm text-foreground-muted">Automatically backup your library changes</p>
              </div>
              <Switch checked={autoSync} onCheckedChange={setAutoSync} />
            </div>
          </div>

          {/* Cloud Services */}
          <div className="space-y-4">
            <h3 className="font-medium">Connected Services</h3>
            {cloudServices.map((service) => {
              const isConnected = connectedServices.includes(service.id);
              const ServiceIcon = service.icon;
              
              return (
                <div key={service.id} className="glass-card p-4 rounded-xl border border-card-border">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-gradient-primary/10 rounded-xl flex items-center justify-center">
                        <ServiceIcon className="w-5 h-5 text-music-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">{service.name}</h4>
                        <p className="text-sm text-foreground-muted">{service.description}</p>
                        <p className="text-xs text-music-accent">{service.storage}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {isConnected ? (
                        <>
                          <CheckCircle className="w-4 h-4 text-music-success" />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDisconnectService(service.id)}
                          >
                            Disconnect
                          </Button>
                        </>
                      ) : (
                        <Button
                          onClick={() => handleConnectService(service.id)}
                          disabled={isConnecting}
                          size="sm"
                          className="bg-gradient-primary"
                        >
                          {isConnecting ? "Connecting..." : "Connect"}
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Sync Status */}
          {syncProgress > 0 && (
            <div className="glass-card p-4 bg-gradient-card rounded-xl">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Syncing...</span>
                <span className="text-sm text-music-primary">{syncProgress}%</span>
              </div>
              <Progress value={syncProgress} className="h-2" />
            </div>
          )}

          {/* Sync Actions */}
          <div className="flex gap-3">
            <Button
              onClick={handleSyncNow}
              disabled={connectedServices.length === 0 || syncProgress > 0}
              className="flex-1 bg-gradient-primary"
            >
              <Cloud className="w-4 h-4 mr-2" />
              Sync Now
            </Button>
            
            <Button variant="outline" className="flex-1">
              <CloudOff className="w-4 h-4 mr-2" />
              View Storage
            </Button>
          </div>

          {/* Sync Statistics */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-music-primary">3,247</div>
              <div className="text-xs text-foreground-muted">Songs Synced</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-music-accent">89</div>
              <div className="text-xs text-foreground-muted">Playlists</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-music-success">12.4GB</div>
              <div className="text-xs text-foreground-muted">Total Size</div>
            </div>
          </div>

          {/* Privacy Notice */}
          <div className="glass-card p-3 bg-card/50 rounded-xl border border-music-primary/10">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-music-accent mt-0.5 flex-shrink-0" />
              <div className="text-xs text-foreground-muted">
                <p className="font-medium mb-1">Privacy First</p>
                <p>Your music library is encrypted before syncing. Only you can access your data.</p>
              </div>
            </div>
          </div>

          {/* OPTISYNCORE Credit */}
          <div className="text-center">
            <p className="text-xs text-foreground-muted">
              Cloud Sync powered by OPTISYNCORE™ Technologies
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}