import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SidebarMenuButton } from "@/components/ui/sidebar";
import { Share2, TrendingUp, Users, Heart, ExternalLink, QrCode, Copy, Play } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import { useToast } from "@/hooks/use-toast";
import { useSidebar } from "@/components/ui/sidebar";

export function SocialHubModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [shareUrl, setShareUrl] = useState("");
  const [playlistName, setPlaylistName] = useState("");
  const { toast } = useToast();
  const { state } = useSidebar();
  const collapsed = state === "collapsed";

  const trendingPlaylists = [
    {
      id: "1",
      name: "Night Drive Synthwave",
      creator: "RetroVibes_89",
      plays: 15420,
      likes: 892,
      tracks: 24,
      genre: "Synthwave",
      isLiked: false
    },
    {
      id: "2", 
      name: "Lo-Fi Study Sessions",
      creator: "ChillBeats_Pro",
      plays: 28750,
      likes: 1340,
      tracks: 45,
      genre: "Lo-Fi",
      isLiked: true
    },
    {
      id: "3",
      name: "Epic Orchestral Gaming",
      creator: "SoundscapeGuru",
      plays: 9876,
      likes: 567,
      tracks: 18,
      genre: "Orchestral",
      isLiked: false
    }
  ];

  const mySharedPlaylists = [
    {
      id: "my1",
      name: "Weekend Vibes",
      shares: 45,
      likes: 23,
      tracks: 32,
      public: true
    },
    {
      id: "my2", 
      name: "Morning Coffee Jazz",
      shares: 12,
      likes: 8,
      tracks: 18,
      public: false
    }
  ];

  const generateShareLink = () => {
    if (!playlistName.trim()) {
      toast({
        title: "Missing Playlist Name",
        description: "Please enter a playlist name to share",
        variant: "destructive",
      });
      return;
    }

    const shareLink = `https://meta-auxdior.fm/playlist/${encodeURIComponent(playlistName.toLowerCase().replace(/\s+/g, '-'))}`;
    setShareUrl(shareLink);
    
    toast({
      title: "Share Link Generated",
      description: "Your playlist is now shareable!",
    });
  };

  const copyShareLink = () => {
    navigator.clipboard.writeText(shareUrl);
    toast({
      title: "Link Copied",
      description: "Share link copied to clipboard",
    });
  };

  const likePlaylist = (playlistId: string) => {
    toast({
      title: "Playlist Liked",
      description: "Added to your liked playlists",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <SidebarMenuButton
          className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
          tooltip={collapsed ? "Social Hub" : undefined}
        >
          <Share2 className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
          {!collapsed && (
            <div className="flex items-center justify-between w-full">
              <span className="font-medium">Social Hub</span>
              <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-music-accent/20 text-music-accent">
                community
              </span>
            </div>
          )}
        </SidebarMenuButton>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-[700px] glass-card">
        <DialogHeader>
          <DialogTitle className="text-gradient flex items-center gap-2">
            <Share2 className="w-5 h-5" />
            Social Hub & Community
          </DialogTitle>
        </DialogHeader>
        
        <Tabs defaultValue="trending" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="trending" className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4" />
              Trending
            </TabsTrigger>
            <TabsTrigger value="share" className="flex items-center gap-2">
              <Share2 className="w-4 h-4" />
              Share
            </TabsTrigger>
            <TabsTrigger value="community" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              My Hub
            </TabsTrigger>
          </TabsList>

          <TabsContent value="trending" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">Trending Playlists</h3>
              <span className="text-xs px-2 py-1 bg-music-success/20 text-music-success rounded-full">
                Live
              </span>
            </div>
            
            <div className="space-y-3">
              {trendingPlaylists.map((playlist) => (
                <div key={playlist.id} className="glass-card p-4 rounded-xl border border-card-border hover:shadow-glow transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center">
                        <Play className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium">{playlist.name}</h4>
                        <p className="text-sm text-foreground-muted">by {playlist.creator}</p>
                        <div className="flex items-center gap-4 text-xs text-foreground-muted mt-1">
                          <span>{playlist.plays.toLocaleString()} plays</span>
                          <span>{playlist.tracks} tracks</span>
                          <span className="px-2 py-0.5 bg-music-accent/20 text-music-accent rounded-full">
                            {playlist.genre}
                          </span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => likePlaylist(playlist.id)}
                        className={`hover:bg-music-primary/10 ${playlist.isLiked ? 'text-red-500' : ''}`}
                      >
                        <Heart className={`w-4 h-4 ${playlist.isLiked ? 'fill-current' : ''}`} />
                        <span className="ml-1 text-xs">{playlist.likes}</span>
                      </Button>
                      <Button size="sm" className="bg-gradient-primary">
                        <Play className="w-4 h-4 mr-1" />
                        Play
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="share" className="space-y-4">
            <div className="glass-card p-4 bg-gradient-card rounded-xl">
              <h3 className="font-medium mb-4">Share Your Playlist</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Playlist Name</label>
                  <Input
                    placeholder="Enter playlist name..."
                    value={playlistName}
                    onChange={(e) => setPlaylistName(e.target.value)}
                    className="glass-input"
                  />
                </div>
                
                <Button
                  onClick={generateShareLink}
                  className="w-full bg-gradient-primary"
                >
                  <Share2 className="w-4 h-4 mr-2" />
                  Generate Share Link
                </Button>
                
                {shareUrl && (
                  <div className="glass-card p-3 bg-card/50 rounded-xl border border-music-primary/20">
                    <div className="flex items-center gap-2 mb-3">
                      <ExternalLink className="w-4 h-4 text-music-success" />
                      <span className="text-sm font-medium">Your playlist is now shareable!</span>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Input
                        value={shareUrl}
                        readOnly
                        className="glass-input text-xs"
                      />
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={copyShareLink}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                    
                    <div className="flex gap-2 mt-3">
                      <Button variant="outline" size="sm" className="flex-1">
                        <QrCode className="w-4 h-4 mr-2" />
                        QR Code
                      </Button>
                      <Button variant="outline" size="sm" className="flex-1">
                        <Share2 className="w-4 h-4 mr-2" />
                        Social Share
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="community" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-medium">My Shared Playlists</h3>
              <Button size="sm" className="bg-gradient-primary">
                <Share2 className="w-4 h-4 mr-2" />
                Share New
              </Button>
            </div>
            
            <div className="space-y-3">
              {mySharedPlaylists.map((playlist) => (
                <div key={playlist.id} className="glass-card p-4 rounded-xl border border-card-border">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium">{playlist.name}</h4>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${
                          playlist.public 
                            ? 'bg-music-success/20 text-music-success' 
                            : 'bg-music-accent/20 text-music-accent'
                        }`}>
                          {playlist.public ? 'Public' : 'Private'}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-xs text-foreground-muted mt-1">
                        <span>{playlist.shares} shares</span>
                        <span>{playlist.likes} likes</span>
                        <span>{playlist.tracks} tracks</span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="sm">
                        <ExternalLink className="w-4 h-4" />
                      </Button>
                      <Button variant="ghost" size="sm">
                        <Copy className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Community Stats */}
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-music-primary">247</div>
                <div className="text-xs text-foreground-muted">Total Shares</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-music-accent">1.2K</div>
                <div className="text-xs text-foreground-muted">Profile Views</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-music-success">89</div>
                <div className="text-xs text-foreground-muted">Followers</div>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {/* OPTISYNCORE Credit */}
        <div className="text-center pt-4 border-t border-card-border">
          <p className="text-xs text-foreground-muted">
            Social Hub powered by OPTISYNCORE™ Community Network
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}