import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useApp } from "@/contexts/AppContext";
import { useState } from "react";

const eqBands = [
  { label: '32Hz', frequency: 32 },
  { label: '64Hz', frequency: 64 },
  { label: '125Hz', frequency: 125 },
  { label: '250Hz', frequency: 250 },
  { label: '500Hz', frequency: 500 },
  { label: '1kHz', frequency: 1000 },
  { label: '2kHz', frequency: 2000 },
  { label: '4kHz', frequency: 4000 },
  { label: '8kHz', frequency: 8000 },
  { label: '16kHz', frequency: 16000 },
];

const presets = {
  pop: [2, 3, 1, 0, -1, -1, 0, 1, 2, 3],
  rock: [4, 3, 2, 1, -1, -2, 0, 2, 3, 4],
  acoustic: [3, 2, 1, 1, 0, 0, 1, 2, 3, 2],
  bassBooster: [6, 5, 4, 2, 0, -1, -1, 0, 1, 2],
  trebleBoost: [-2, -1, 0, 1, 2, 3, 4, 5, 6, 7],
  vocalBoost: [-2, -1, 0, 2, 4, 4, 2, 1, 0, -1],
  headphones: [3, 2, 1, 0, -1, -2, -1, 1, 2, 3],
  deep: [4, 3, 2, 1, 1, 0, -1, -2, -1, 2],
  electronic: [3, 2, 0, -1, -2, 0, 2, 3, 4, 5],
  latin: [2, 1, 0, 0, -1, -1, 0, 2, 3, 4],
  balanced: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
};

export function EqualizerModal() {
  const { isEqualizerOpen, toggleEqualizer, eqPreset, setEQPreset } = useApp();
  const [customEQ, setCustomEQ] = useState([0, 0, 0, 0, 0, 0, 0, 0, 0, 0]);

  const handlePresetChange = (preset: keyof typeof presets) => {
    setEQPreset(preset);
    setCustomEQ(presets[preset]);
  };

  const handleCustomChange = (bandIndex: number, value: number[]) => {
    const newEQ = [...customEQ];
    newEQ[bandIndex] = value[0];
    setCustomEQ(newEQ);
    setEQPreset('custom');
  };

  return (
    <Dialog open={isEqualizerOpen} onOpenChange={toggleEqualizer}>
      <DialogContent className="glass-card max-w-4xl">
        <DialogHeader>
          <DialogTitle className="text-gradient">10-Band Equalizer</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Presets */}
          <div className="grid grid-cols-6 gap-2">
            <Button
              variant={eqPreset === 'pop' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('pop')}
              className="text-xs"
            >
              Pop
            </Button>
            <Button
              variant={eqPreset === 'rock' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('rock')}
              className="text-xs"
            >
              Rock
            </Button>
            <Button
              variant={eqPreset === 'acoustic' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('acoustic')}
              className="text-xs"
            >
              Acoustic
            </Button>
            <Button
              variant={eqPreset === 'bassBooster' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('bassBooster')}
              className="text-xs"
            >
              Bass Boost
            </Button>
            <Button
              variant={eqPreset === 'trebleBoost' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('trebleBoost')}
              className="text-xs"
            >
              Treble Boost
            </Button>
            <Button
              variant={eqPreset === 'vocalBoost' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('vocalBoost')}
              className="text-xs"
            >
              Vocal Boost
            </Button>
            <Button
              variant={eqPreset === 'headphones' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('headphones')}
              className="text-xs"
            >
              Headphones
            </Button>
            <Button
              variant={eqPreset === 'deep' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('deep')}
              className="text-xs"
            >
              Deep
            </Button>
            <Button
              variant={eqPreset === 'electronic' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('electronic')}
              className="text-xs"
            >
              Electronic
            </Button>
            <Button
              variant={eqPreset === 'latin' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('latin')}
              className="text-xs"
            >
              Latin
            </Button>
            <Button
              variant={eqPreset === 'balanced' ? 'default' : 'outline'}
              onClick={() => handlePresetChange('balanced')}
              className="text-xs col-span-2"
            >
              Balanced
            </Button>
          </div>

          {/* EQ Bands */}
          <div className="grid grid-cols-10 gap-3">
            {eqBands.map((band, index) => (
              <div key={band.frequency} className="flex flex-col items-center space-y-4">
                <div className="text-xs font-medium text-music-primary">{band.label}</div>
                <div className="h-32 flex items-center">
                  <Slider
                    orientation="vertical"
                    value={[customEQ[index]]}
                    onValueChange={(value) => handleCustomChange(index, value)}
                    max={10}
                    min={-10}
                    step={1}
                    className="h-full"
                  />
                </div>
                <div className="text-xs text-foreground-muted">
                  {customEQ[index] > 0 ? '+' : ''}{customEQ[index]}dB
                </div>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center pt-4 border-t border-card-border">
            <Button variant="outline" onClick={() => handlePresetChange('balanced')}>
              Reset
            </Button>
            <div className="text-sm text-music-primary">
              Preset: {eqPreset === 'custom' ? 'Custom' : 
                eqPreset === 'bassBooster' ? 'Bass Booster' :
                eqPreset === 'trebleBoost' ? 'Treble Boost' :
                eqPreset === 'vocalBoost' ? 'Vocal Boost' :
                eqPreset.charAt(0).toUpperCase() + eqPreset.slice(1)}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}