import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { SidebarMenuButton } from "@/components/ui/sidebar";
import { Wand2, Play, Download, Loader2 } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import { useToast } from "@/hooks/use-toast";
import { useSidebar } from "@/components/ui/sidebar";

export function AIRemixModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [remixType, setRemixType] = useState("");
  const [intensity, setIntensity] = useState([50]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [previewUrl, setPreviewUrl] = useState("");
  const { currentTrack } = useApp();
  const { toast } = useToast();
  const { state } = useSidebar();
  const collapsed = state === "collapsed";

  const remixOptions = [
    { value: "slowed-reverb", label: "Slowed + Reverb", description: "Dreamy, atmospheric version" },
    { value: "bass-boost", label: "Bass Boost", description: "Enhanced low frequencies" },
    { value: "lofi", label: "Lo-Fi", description: "Warm, nostalgic sound" },
    { value: "speed-up", label: "Speed Up", description: "Energetic, faster tempo" },
    { value: "echo", label: "Echo", description: "Spacious, reverberant" },
  ];

  const handleGenerateRemix = async () => {
    if (!currentTrack || !remixType) {
      toast({
        title: "Missing Requirements",
        description: "Please select a track and remix type",
        variant: "destructive",
      });
      return;
    }

    setIsGenerating(true);
    
    // Simulate AI processing
    setTimeout(() => {
      setPreviewUrl(`/preview-${remixType}-${currentTrack.id}.mp3`);
      setIsGenerating(false);
      toast({
        title: "Remix Generated",
        description: `${remixType} remix of "${currentTrack.title}" is ready!`,
      });
    }, 3000);
  };

  const handleSaveRemix = () => {
    toast({
      title: "Remix Saved",
      description: "Added to your library as a new track",
    });
    setIsOpen(false);
    setPreviewUrl("");
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <SidebarMenuButton
          className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
          tooltip={collapsed ? "AI Remix Generator" : undefined}
        >
          <Wand2 className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
          {!collapsed && (
            <div className="flex items-center justify-between w-full">
              <span className="font-medium">AI Remix Generator</span>
              <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-gradient-primary/20 text-music-primary">
                ai
              </span>
            </div>
          )}
        </SidebarMenuButton>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-[500px] glass-card">
        <DialogHeader>
          <DialogTitle className="text-gradient">AI Remix Generator</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Current Track Info */}
          {currentTrack && (
            <div className="glass-card p-4 bg-gradient-card rounded-xl">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-primary rounded-xl flex items-center justify-center">
                  <Wand2 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-semibold">{currentTrack.title}</h3>
                  <p className="text-sm text-foreground-muted">{currentTrack.artist}</p>
                </div>
              </div>
            </div>
          )}

          {/* Remix Type Selection */}
          <div className="space-y-3">
            <label className="text-sm font-medium">Remix Style</label>
            <Select value={remixType} onValueChange={setRemixType}>
              <SelectTrigger className="glass-input">
                <SelectValue placeholder="Choose a remix style..." />
              </SelectTrigger>
              <SelectContent>
                {remixOptions.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    <div>
                      <div className="font-medium">{option.label}</div>
                      <div className="text-xs text-foreground-muted">{option.description}</div>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Intensity Control */}
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium">Effect Intensity</label>
              <span className="text-sm text-music-primary">{intensity[0]}%</span>
            </div>
            <Slider
              value={intensity}
              onValueChange={setIntensity}
              max={100}
              step={1}
              className="remix-slider"
            />
          </div>

          {/* Generate Button */}
          <Button
            onClick={handleGenerateRemix}
            disabled={!currentTrack || !remixType || isGenerating}
            className="w-full bg-gradient-primary hover:shadow-glow"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Generating Remix...
              </>
            ) : (
              <>
                <Wand2 className="w-4 h-4 mr-2" />
                Generate AI Remix
              </>
            )}
          </Button>

          {/* Preview Section */}
          {previewUrl && (
            <div className="glass-card p-4 bg-gradient-card rounded-xl space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium text-music-primary">Preview Ready</h4>
                <span className="text-xs px-2 py-1 bg-music-success/20 text-music-success rounded-full">
                  Generated
                </span>
              </div>
              
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1">
                  <Play className="w-4 h-4 mr-2" />
                  Preview
                </Button>
                <Button 
                  onClick={handleSaveRemix}
                  size="sm" 
                  className="flex-1 bg-gradient-primary"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Save to Library
                </Button>
              </div>
            </div>
          )}

          {/* OPTISYNCORE Credit */}
          <div className="text-center">
            <p className="text-xs text-foreground-muted">
              Powered by OPTISYNCORE™ AI Engine
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}