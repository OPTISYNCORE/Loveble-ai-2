import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useApp } from "@/contexts/AppContext";
import { useState } from "react";
import { Scissors, Play, Pause, Save, RefreshCw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

export function AudioTrimmerModal() {
  const { currentTrack, tracks } = useApp();
  const [isOpen, setIsOpen] = useState(false);
  const [selectedTrack, setSelectedTrack] = useState(currentTrack?.id || "");
  const [startTime, setStartTime] = useState([0]);
  const [endTime, setEndTime] = useState([100]);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [saveAsNew, setSaveAsNew] = useState(true);
  const { toast } = useToast();

  const formatTime = (percentage: number) => {
    // Convert percentage to time format (mock calculation)
    const totalSeconds = 240; // placeholder: 4 minutes
    const seconds = Math.floor((percentage / 100) * totalSeconds);
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleTrim = async () => {
    if (startTime[0] >= endTime[0]) {
      toast({
        title: "Invalid Range",
        description: "Start time must be before end time",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    
    // Placeholder for actual trimming logic
    setTimeout(() => {
      setIsProcessing(false);
      const track = tracks.find(t => t.id === selectedTrack);
      toast({
        title: "Trim Complete!",
        description: `Successfully trimmed "${track?.title}" from ${formatTime(startTime[0])} to ${formatTime(endTime[0])}`,
      });
      setIsOpen(false);
    }, 2000);
  };

  const handlePreview = () => {
    setIsPlaying(!isPlaying);
    // Placeholder for preview functionality
    toast({
      title: isPlaying ? "Preview Stopped" : "Preview Playing",
      description: `Playing trimmed section: ${formatTime(startTime[0])} - ${formatTime(endTime[0])}`,
    });
  };

  return (
    <>
      <Button
        variant="ghost"
        onClick={() => setIsOpen(true)}
        className="w-full justify-start gap-3 transition-all duration-300 hover:bg-music-primary/10"
      >
        <Scissors className="w-5 h-5 text-music-primary" />
        <span>Audio Trimmer</span>
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="glass-card max-w-xl">
          <DialogHeader>
            <DialogTitle className="text-gradient flex items-center gap-2">
              <Scissors className="w-5 h-5" />
              Audio Trimmer
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Track Selection */}
            <div>
              <h3 className="font-semibold mb-3">Select Track</h3>
              <div className="grid gap-2 max-h-32 overflow-y-auto">
                {tracks.map((track) => (
                  <Card 
                    key={track.id} 
                    className={`cursor-pointer transition-all ${
                      selectedTrack === track.id ? 'border-music-primary bg-music-primary/10' : 'glass-card'
                    }`}
                    onClick={() => setSelectedTrack(track.id)}
                  >
                    <CardContent className="p-3 flex items-center gap-3">
                      <div className="w-3 h-3 rounded-full border-2 border-music-primary flex items-center justify-center">
                        {selectedTrack === track.id && (
                          <div className="w-1.5 h-1.5 bg-music-primary rounded-full" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium truncate">{track.title}</p>
                        <p className="text-sm text-foreground-muted truncate">{track.artist} • {track.duration}</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Waveform Placeholder */}
            <div>
              <h3 className="font-semibold mb-3">Waveform</h3>
              <div className="h-24 glass-card p-4 flex items-center justify-center bg-gradient-to-r from-music-primary/20 via-music-primary/40 to-music-primary/20 rounded-lg">
                <div className="flex items-center gap-1">
                  {Array.from({ length: 50 }).map((_, i) => (
                    <div
                      key={i}
                      className={`w-1 bg-music-primary/60 rounded-full ${
                        i >= (startTime[0] / 100) * 50 && i <= (endTime[0] / 100) * 50
                          ? 'bg-music-primary' 
                          : 'bg-music-primary/30'
                      }`}
                      style={{ 
                        height: `${Math.random() * 40 + 10}px`,
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>

            {/* Time Controls */}
            <div className="space-y-4">
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="font-semibold">Start Time</label>
                  <span className="text-sm text-music-primary">{formatTime(startTime[0])}</span>
                </div>
                <Slider
                  value={startTime}
                  onValueChange={setStartTime}
                  max={endTime[0] - 1}
                  min={0}
                  step={1}
                  className="w-full"
                />
              </div>
              
              <div>
                <div className="flex justify-between items-center mb-2">
                  <label className="font-semibold">End Time</label>
                  <span className="text-sm text-music-primary">{formatTime(endTime[0])}</span>
                </div>
                <Slider
                  value={endTime}
                  onValueChange={setEndTime}
                  max={100}
                  min={startTime[0] + 1}
                  step={1}
                  className="w-full"
                />
              </div>
            </div>

            {/* Preview & Save Options */}
            <div className="flex items-center justify-between p-3 glass-card">
              <Button variant="outline" onClick={handlePreview} className="gap-2">
                {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                Preview Selection
              </Button>
              
              <div className="flex items-center gap-3">
                <label className="text-sm flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={saveAsNew}
                    onChange={(e) => setSaveAsNew(e.target.checked)}
                    className="rounded border-music-primary"
                  />
                  Save as new file
                </label>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-3 pt-4">
              <Button variant="outline" onClick={() => setIsOpen(false)} className="flex-1">
                Cancel
              </Button>
              <Button 
                onClick={handleTrim} 
                disabled={isProcessing || !selectedTrack}
                className="flex-1 gap-2"
              >
                {isProcessing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    Trimming...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Trim & Save
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}