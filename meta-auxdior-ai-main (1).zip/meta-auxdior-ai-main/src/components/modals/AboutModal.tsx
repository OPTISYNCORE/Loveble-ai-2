import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { SidebarMenuButton } from "@/components/ui/sidebar";
import { Info, Sparkles, Cloud, Share2, Wand2, Music } from "lucide-react";
import logoImage from "@/assets/meta-auxdior-logo.png";
import { useSidebar } from "@/components/ui/sidebar";

export function AboutModal() {
  const [isOpen, setIsOpen] = useState(false);
  const { state } = useSidebar();
  const collapsed = state === "collapsed";

  const features = [
    {
      icon: Wand2,
      title: "AI Remix Generator",
      description: "Transform your music with AI-powered remix styles including Lo-Fi, Bass Boost, and more."
    },
    {
      icon: Music,
      title: "Real-Time Visualizer",
      description: "Immersive visual experiences with equalizer bars, waveforms, particles, and neon flow effects."
    },
    {
      icon: Cloud,
      title: "Cloud Library Sync",
      description: "Seamlessly sync your library across devices with Google Drive, Dropbox, and OneDrive integration."
    },
    {
      icon: Share2,
      title: "Social Community Hub",
      description: "Share playlists, discover trending music, and connect with the Meta-Auxdior community."
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <SidebarMenuButton
          className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
          tooltip={collapsed ? "About" : undefined}
        >
          <Info className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
          {!collapsed && <span className="font-medium">About</span>}
        </SidebarMenuButton>
      </DialogTrigger>
      
      <DialogContent className="sm:max-w-[600px] glass-card">
        <DialogHeader>
          <DialogTitle className="text-gradient flex items-center gap-2">
            <img 
              src={logoImage} 
              alt="Meta-Auxdior.FM-35 Logo" 
              className="w-6 h-6 object-contain"
            />
            About Meta-Auxdior.FM-35™
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Hero Section */}
          <div className="text-center glass-card p-6 bg-gradient-card rounded-xl">
            <div className="w-20 h-20 mx-auto mb-4 bg-gradient-primary/10 rounded-2xl flex items-center justify-center border border-music-primary/20">
              <img 
                src={logoImage} 
                alt="Meta-Auxdior.FM-35 Logo" 
                className="w-12 h-12 object-contain"
              />
            </div>
            <h2 className="text-2xl font-bold text-gradient mb-2">Meta-Auxdior.FM-35™</h2>
            <p className="text-lg text-music-primary mb-3">Premium AI Music Ecosystem</p>
            <p className="text-sm text-foreground-muted leading-relaxed">
              The future of music experience, powered by advanced AI technology and seamless cloud integration.
            </p>
          </div>

          {/* Premium Features */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-music-primary" />
              <h3 className="font-semibold text-music-primary">Premium AI Features</h3>
            </div>
            
            <div className="grid gap-3">
              {features.map((feature, index) => {
                const IconComponent = feature.icon;
                return (
                  <div key={index} className="glass-card p-4 rounded-xl border border-card-border">
                    <div className="flex items-start gap-3">
                      <div className="w-10 h-10 bg-gradient-primary/10 rounded-xl flex items-center justify-center flex-shrink-0">
                        <IconComponent className="w-5 h-5 text-music-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium text-sm mb-1">{feature.title}</h4>
                        <p className="text-xs text-foreground-muted leading-relaxed">{feature.description}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Technology Stack */}
          <div className="glass-card p-4 bg-gradient-card rounded-xl">
            <h3 className="font-semibold mb-3 text-music-primary">Core Technologies</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="font-medium">Audio Processing</div>
                <div className="text-xs text-foreground-muted">10-Band Equalizer, Pro Audio Tools</div>
              </div>
              <div>
                <div className="font-medium">AI Engine</div>
                <div className="text-xs text-foreground-muted">Real-time Remix Generation</div>
              </div>
              <div>
                <div className="font-medium">Cross-Platform</div>
                <div className="text-xs text-foreground-muted">React Native & Flutter Ready</div>
              </div>
              <div>
                <div className="font-medium">Cloud Integration</div>
                <div className="text-xs text-foreground-muted">Multi-provider Sync</div>
              </div>
            </div>
          </div>

          {/* Copyright and Licensing */}
          <div className="space-y-3">
            <div className="glass-card p-4 bg-card/30 rounded-xl border border-music-primary/10">
              <div className="text-center space-y-2">
                <p className="text-sm font-medium text-music-primary">
                  "Powered by OPTISYNCORE™ — The Future in Sync"
                </p>
                <p className="text-xs text-foreground-muted leading-relaxed">
                  Meta-Auxdior.FM-35™ is enhanced with AI remixing, cloud sync, and social sharing, 
                  licensed under OPTISYNCORE Technologies.
                </p>
                <p className="text-xs text-foreground-muted font-medium">
                  © 2025 OPTISYNCORE. All rights reserved.
                </p>
              </div>
            </div>

            {/* Version Info */}
            <div className="flex justify-between items-center text-xs text-foreground-muted">
              <span>Version 35.0.0</span>
              <span>Build 2025.01</span>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}