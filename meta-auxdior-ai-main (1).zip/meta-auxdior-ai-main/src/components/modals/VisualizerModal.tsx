import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SidebarMenuButton } from "@/components/ui/sidebar";
import { BarChart3, X, Maximize2 } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import { useSidebar } from "@/components/ui/sidebar";

export function VisualizerModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [visualizerType, setVisualizerType] = useState("equalizer-bars");
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>();
  const { currentTrack, isPlaying } = useApp();
  const { state } = useSidebar();
  const collapsed = state === "collapsed";

  const visualizerTypes = [
    { value: "equalizer-bars", label: "Equalizer Bars", description: "Classic frequency bars" },
    { value: "waveform", label: "Waveform", description: "Audio waveform visualization" },
    { value: "particles", label: "Particles", description: "Floating particle effects" },
    { value: "neon-flow", label: "Neon Flow", description: "Flowing neon patterns" },
  ];

  // Visualizer animation logic
  useEffect(() => {
    if (!isOpen || !canvasRef.current || !isPlaying) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const updateCanvasSize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);

    const animate = () => {
      const width = canvas.width / window.devicePixelRatio;
      const height = canvas.height / window.devicePixelRatio;
      
      ctx.clearRect(0, 0, width, height);

      // Generate mock audio data
      const time = Date.now() * 0.001;
      const bars = 32;
      const barWidth = width / bars;

      switch (visualizerType) {
        case "equalizer-bars":
          for (let i = 0; i < bars; i++) {
            const barHeight = (Math.sin(time * 2 + i * 0.3) * 0.5 + 0.5) * height * 0.8;
            const hue = (i / bars) * 360 + time * 30;
            
            ctx.fillStyle = `hsl(${hue}, 70%, 60%)`;
            ctx.fillRect(i * barWidth + 2, height - barHeight, barWidth - 4, barHeight);
            
            // Add glow effect
            ctx.shadowColor = `hsl(${hue}, 70%, 60%)`;
            ctx.shadowBlur = 10;
            ctx.fillRect(i * barWidth + 2, height - barHeight, barWidth - 4, barHeight);
            ctx.shadowBlur = 0;
          }
          break;

        case "waveform":
          ctx.strokeStyle = '#00ff88';
          ctx.lineWidth = 3;
          ctx.shadowColor = '#00ff88';
          ctx.shadowBlur = 10;
          ctx.beginPath();
          
          for (let x = 0; x < width; x++) {
            const y = height / 2 + Math.sin(x * 0.02 + time * 3) * height * 0.3 * Math.sin(time * 2);
            if (x === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();
          ctx.shadowBlur = 0;
          break;

        case "particles":
          const particles = 50;
          for (let i = 0; i < particles; i++) {
            const x = (Math.sin(time + i) * 0.5 + 0.5) * width;
            const y = (Math.cos(time * 1.5 + i * 0.5) * 0.5 + 0.5) * height;
            const size = Math.sin(time * 3 + i) * 3 + 5;
            const hue = (time * 50 + i * 10) % 360;
            
            ctx.fillStyle = `hsl(${hue}, 70%, 60%)`;
            ctx.shadowColor = `hsl(${hue}, 70%, 60%)`;
            ctx.shadowBlur = 15;
            ctx.beginPath();
            ctx.arc(x, y, size, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.shadowBlur = 0;
          break;

        case "neon-flow":
          const lines = 8;
          for (let i = 0; i < lines; i++) {
            ctx.strokeStyle = `hsl(${(time * 50 + i * 45) % 360}, 70%, 60%)`;
            ctx.lineWidth = 4;
            ctx.shadowColor = ctx.strokeStyle;
            ctx.shadowBlur = 15;
            ctx.beginPath();
            
            const offsetY = (i / lines) * height;
            for (let x = 0; x < width; x++) {
              const y = offsetY + Math.sin(x * 0.01 + time * 2 + i) * 50;
              if (x === 0) ctx.moveTo(x, y);
              else ctx.lineTo(x, y);
            }
            ctx.stroke();
          }
          ctx.shadowBlur = 0;
          break;
      }

      animationRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      window.removeEventListener('resize', updateCanvasSize);
    };
  }, [isOpen, isPlaying, visualizerType]);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <SidebarMenuButton
          className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
          tooltip={collapsed ? "Visualizer Mode" : undefined}
        >
          <BarChart3 className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
          {!collapsed && (
            <div className="flex items-center justify-between w-full">
              <span className="font-medium">Visualizer Mode</span>
              <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-music-accent/20 text-music-accent">
                live
              </span>
            </div>
          )}
        </SidebarMenuButton>
      </DialogTrigger>
      
      <DialogContent 
        className={`glass-card transition-all duration-300 ${
          isFullscreen 
            ? "fixed inset-0 w-screen h-screen max-w-none max-h-none rounded-none" 
            : "sm:max-w-[800px] sm:max-h-[600px]"
        }`}
      >
        <DialogHeader className={isFullscreen ? "absolute top-4 left-4 z-10" : ""}>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-gradient">
              {isFullscreen ? "Full Screen Visualizer" : "Visualizer Mode"}
            </DialogTitle>
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleFullscreen}
                className="hover:bg-music-primary/10"
              >
                <Maximize2 className="w-4 h-4" />
              </Button>
              {isFullscreen && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setIsOpen(false)}
                  className="hover:bg-music-primary/10"
                >
                  <X className="w-4 h-4" />
                </Button>
              )}
            </div>
          </div>
        </DialogHeader>
        
        <div className={`space-y-4 ${isFullscreen ? "h-full pt-16" : ""}`}>
          {/* Controls */}
          {!isFullscreen && (
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <Select value={visualizerType} onValueChange={setVisualizerType}>
                  <SelectTrigger className="glass-input">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {visualizerTypes.map((type) => (
                      <SelectItem key={type.value} value={type.value}>
                        <div>
                          <div className="font-medium">{type.label}</div>
                          <div className="text-xs text-foreground-muted">{type.description}</div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {/* Visualizer Canvas */}
          <div className={`relative bg-black/50 rounded-xl overflow-hidden border border-music-primary/20 ${
            isFullscreen ? "flex-1" : "h-80"
          }`}>
            <canvas
              ref={canvasRef}
              className="w-full h-full"
              style={{ background: 'linear-gradient(45deg, #0a0a0a, #1a1a2e)' }}
            />
            
            {/* Current Track Info Overlay */}
            {currentTrack && (
              <div className={`absolute ${isFullscreen ? "bottom-8 left-8" : "bottom-4 left-4"} glass-card p-3 rounded-lg`}>
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 bg-music-success rounded-full ${isPlaying ? 'animate-pulse' : ''}`}></div>
                  <div>
                    <p className="font-medium text-sm">{currentTrack.title}</p>
                    <p className="text-xs text-foreground-muted">{currentTrack.artist}</p>
                  </div>
                </div>
              </div>
            )}

            {/* OPTISYNCORE Watermark */}
            <div className={`absolute ${isFullscreen ? "bottom-8 right-8" : "bottom-4 right-4"} opacity-50`}>
              <p className="text-xs text-foreground-muted">
                Powered by OPTISYNCORE™
              </p>
            </div>
          </div>

          {!isPlaying && (
            <div className="text-center py-8">
              <p className="text-foreground-muted mb-2">Play a track to see the visualizer</p>
              <div className="w-12 h-12 mx-auto bg-gradient-primary/20 rounded-full flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-music-primary" />
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}