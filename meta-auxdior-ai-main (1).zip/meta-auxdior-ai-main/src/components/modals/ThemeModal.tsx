import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useApp } from "@/contexts/AppContext";
import { Palette, Sun, Moon, Zap } from "lucide-react";
import { useState } from "react";

const themes = [
  { id: 'light', name: 'Light', icon: Sun, description: 'Clean and bright interface' },
  { id: 'dark', name: 'Dark', icon: Moon, description: 'Easy on the eyes' },
  { id: 'adaptive', name: 'Adaptive', icon: Zap, description: 'Follows system preference' },
];

export function ThemeModal() {
  const { theme, setTheme } = useApp();
  const [isOpen, setIsOpen] = useState(false);

  const handleThemeChange = (newTheme: 'light' | 'dark' | 'adaptive') => {
    setTheme(newTheme);
    setIsOpen(false);
  };

  return (
    <>
      <Button
        variant="ghost"
        onClick={() => setIsOpen(true)}
        className="w-full justify-start gap-3 transition-all duration-300 hover:bg-music-primary/10"
      >
        <Palette className="w-5 h-5 text-music-primary" />
        <span>Themes</span>
        <span className="ml-auto text-xs text-music-primary capitalize">
          {theme}
        </span>
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="glass-card max-w-md">
          <DialogHeader>
            <DialogTitle className="text-gradient flex items-center gap-2">
              <Palette className="w-5 h-5" />
              Choose Theme
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-3">
            {themes.map((themeOption) => {
              const Icon = themeOption.icon;
              const isActive = theme === themeOption.id;
              
              return (
                <Button
                  key={themeOption.id}
                  variant={isActive ? "default" : "outline"}
                  onClick={() => handleThemeChange(themeOption.id as any)}
                  className="w-full justify-start gap-3 h-16 p-4"
                >
                  <Icon className="w-5 h-5" />
                  <div className="flex-1 text-left">
                    <div className="font-medium">{themeOption.name}</div>
                    <div className="text-xs text-foreground-muted">
                      {themeOption.description}
                    </div>
                  </div>
                  {isActive && (
                    <div className="w-2 h-2 bg-music-primary rounded-full"></div>
                  )}
                </Button>
              );
            })}
          </div>

          <div className="mt-6 p-4 glass-card bg-gradient-primary/10 border border-music-primary/20">
            <div className="text-sm text-foreground-muted">
              <strong>Current:</strong> {themes.find(t => t.id === theme)?.name} theme is active
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}