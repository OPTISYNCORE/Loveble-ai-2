import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useApp } from "@/contexts/AppContext";
import { Bot, Mic, Send, Sparkles, Music } from "lucide-react";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

const sampleQueries = [
  "Play some jazz music",
  "Create a workout playlist",
  "Find songs similar to current track",
  "Play relaxing ambient music"
];

export function AIAssistModal() {
  const { isAIAssistOpen, toggleAIAssist, aiRecommendations, getAIRecommendations } = useApp();
  const [query, setQuery] = useState('');
  const [isListening, setIsListening] = useState(false);

  const handleSearch = (searchQuery: string) => {
    console.log('AI Search:', searchQuery);
    getAIRecommendations();
    setQuery('');
  };

  const handleVoiceInput = () => {
    setIsListening(!isListening);
    // Placeholder for voice input functionality
    setTimeout(() => {
      setIsListening(false);
      setQuery("Play some chill music");
    }, 2000);
  };

  return (
    <Dialog open={isAIAssistOpen} onOpenChange={toggleAIAssist}>
      <DialogContent className="glass-card max-w-2xl max-h-[80vh] overflow-auto">
        <DialogHeader>
          <DialogTitle className="text-gradient flex items-center gap-2">
            <Bot className="w-5 h-5" />
            AI Music Assistant
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Search Input */}
          <div className="flex gap-2">
            <div className="flex-1 relative">
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask AI: 'Play jazz music' or 'Create party playlist'"
                className="pr-12"
                onKeyPress={(e) => e.key === 'Enter' && query && handleSearch(query)}
              />
              <Button
                size="sm"
                variant="ghost"
                onClick={() => query && handleSearch(query)}
                className="absolute right-1 top-1 h-8 w-8 p-0"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <Button
              onClick={handleVoiceInput}
              variant={isListening ? "default" : "outline"}
              className="gap-2"
            >
              <Mic className={`w-4 h-4 ${isListening ? 'animate-pulse' : ''}`} />
              {isListening ? 'Listening...' : 'Voice'}
            </Button>
          </div>

          {/* Quick Actions */}
          <div>
            <h3 className="text-sm font-medium mb-3">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-2">
              {sampleQueries.map((sampleQuery, index) => (
                <Button
                  key={index}
                  variant="outline"
                  onClick={() => handleSearch(sampleQuery)}
                  className="text-sm justify-start"
                >
                  {sampleQuery}
                </Button>
              ))}
            </div>
          </div>

          {/* AI Recommendations */}
          {aiRecommendations.length > 0 && (
            <div>
              <h3 className="text-sm font-medium mb-3 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-music-primary" />
                AI Recommendations
              </h3>
              <div className="space-y-2">
                {aiRecommendations.map((track) => (
                  <Card key={track.id} className="glass-card">
                    <CardContent className="p-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-gradient-primary/20 flex items-center justify-center">
                          <Music className="w-5 h-5 text-music-primary" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium">{track.title}</h4>
                          <p className="text-sm text-foreground-muted">{track.artist}</p>
                        </div>
                        <Button size="sm" variant="outline">
                          Play
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* AI Status */}
          <div className="glass-card p-4 bg-gradient-primary/10 border border-music-primary/20">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 bg-music-success rounded-full animate-pulse-glow"></div>
              <span className="text-sm font-medium text-music-primary">AI Assistant Active</span>
            </div>
            <p className="text-xs text-foreground-muted">
              Natural language music search and recommendations powered by AI
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}