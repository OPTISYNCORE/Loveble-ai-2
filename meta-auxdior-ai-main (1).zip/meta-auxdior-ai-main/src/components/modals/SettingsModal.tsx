import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Settings, Volume2, Palette, Bot } from "lucide-react";
import { useState } from "react";
import { Separator } from "@/components/ui/separator";

export function SettingsModal() {
  const [isOpen, setIsOpen] = useState(false);
  const [settings, setSettings] = useState({
    audioQuality: 'high',
    enableAI: true,
    autoPlay: true,
    notifications: true,
    crossfade: 2,
    gaplessPlayback: true,
    showLyrics: true,
    darkMode: true,
  });

  const handleSettingChange = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    // Save to localStorage
    localStorage.setItem('appSettings', JSON.stringify({ ...settings, [key]: value }));
  };

  return (
    <>
      <Button
        variant="ghost"
        onClick={() => setIsOpen(true)}
        className="w-full justify-start gap-3 transition-all duration-300 hover:bg-music-primary/10"
      >
        <Settings className="w-5 h-5 text-music-primary" />
        <span>Settings</span>
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="glass-card max-w-2xl max-h-[80vh] overflow-auto">
          <DialogHeader>
            <DialogTitle className="text-gradient flex items-center gap-2">
              <Settings className="w-5 h-5" />
              App Settings
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Audio Settings */}
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-music-primary" />
                Audio Settings
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="audio-quality">Audio Quality</Label>
                  <Select value={settings.audioQuality} onValueChange={(value) => handleSettingChange('audioQuality', value)}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low (128kbps)</SelectItem>
                      <SelectItem value="medium">Medium (320kbps)</SelectItem>
                      <SelectItem value="high">High (FLAC)</SelectItem>
                      <SelectItem value="ultra">Ultra (24-bit/192kHz)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="crossfade">Crossfade Duration</Label>
                  <div className="w-40 flex items-center gap-2">
                    <Slider
                      value={[settings.crossfade]}
                      onValueChange={(value) => handleSettingChange('crossfade', value[0])}
                      max={10}
                      step={1}
                      className="flex-1"
                    />
                    <span className="text-sm text-foreground-muted w-8">{settings.crossfade}s</span>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="gapless">Gapless Playback</Label>
                  <Switch
                    id="gapless"
                    checked={settings.gaplessPlayback}
                    onCheckedChange={(checked) => handleSettingChange('gaplessPlayback', checked)}
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* Interface Settings */}
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Palette className="w-5 h-5 text-music-primary" />
                Interface
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label htmlFor="auto-play">Auto-play Similar Songs</Label>
                  <Switch
                    id="auto-play"
                    checked={settings.autoPlay}
                    onCheckedChange={(checked) => handleSettingChange('autoPlay', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="show-lyrics">Show Lyrics</Label>
                  <Switch
                    id="show-lyrics"
                    checked={settings.showLyrics}
                    onCheckedChange={(checked) => handleSettingChange('showLyrics', checked)}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <Label htmlFor="notifications">Notifications</Label>
                  <Switch
                    id="notifications"
                    checked={settings.notifications}
                    onCheckedChange={(checked) => handleSettingChange('notifications', checked)}
                  />
                </div>
              </div>
            </div>

            <Separator />

            {/* AI Settings */}
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <Bot className="w-5 h-5 text-music-primary" />
                AI Features
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="enable-ai">Enable AI Assistant</Label>
                    <p className="text-sm text-foreground-muted">Smart recommendations and voice control</p>
                  </div>
                  <Switch
                    id="enable-ai"
                    checked={settings.enableAI}
                    onCheckedChange={(checked) => handleSettingChange('enableAI', checked)}
                  />
                </div>
              </div>
            </div>

            {/* Current Settings Display */}
            <div className="p-4 glass-card bg-gradient-primary/10 border border-music-primary/20">
              <h4 className="font-medium text-music-primary mb-2">Current Configuration</h4>
              <div className="text-sm text-foreground-muted space-y-1">
                <p>Audio: {settings.audioQuality.charAt(0).toUpperCase() + settings.audioQuality.slice(1)} quality</p>
                <p>Crossfade: {settings.crossfade} seconds</p>
                <p>AI Features: {settings.enableAI ? 'Enabled' : 'Disabled'}</p>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}