import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import {
  Library,
  Repeat1,
  BarChart3,
  Square,
  Folder,
  Car,
  Music2,
  LogOut,
  Volume2,
  Scissors,
  Merge,
  Disc3,
  Wand2,
  Cloud,
  Share2,
} from "lucide-react";
import logoImage from "@/assets/meta-auxdior-logo.png";
import sidebarWallpaper from "@/assets/sidebar-wallpaper.jpg";
import { useApp } from "@/contexts/AppContext";
import { EqualizerModal } from "./modals/EqualizerModal";
import { SleepTimerModal } from "./modals/SleepTimerModal";
import { ThemeModal } from "./modals/ThemeModal";
import { FeedbackModal } from "./modals/FeedbackModal";
import { SettingsModal } from "./modals/SettingsModal";
import { HiddenModeModal } from "./modes/HiddenMode";
import { AudioMergerModal } from "./modals/AudioMergerModal";
import { AudioTrimmerModal } from "./modals/AudioTrimmerModal";
import { AIRemixModal } from "./modals/AIRemixModal";
import { VisualizerModal } from "./modals/VisualizerModal";
import { CloudSyncModal } from "./modals/CloudSyncModal";
import { SocialHubModal } from "./modals/SocialHubModal";
import { AboutModal } from "./modals/AboutModal";
import { useToast } from "@/hooks/use-toast";

export function MusicSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { 
    scanLibrary, 
    isScanning, 
    toggleRepeat, 
    repeatMode, 
    toggleWidget, 
    toggleDriveMode, 
    setIsDJModeActive,
    toggleLyricsMode, 
    isLyricsModeActive
  } = useApp();
  const { toast } = useToast();

  const handleScanLibrary = () => {
    scanLibrary();
    toast({
      title: "Scanning Library",
      description: "Searching for audio files...",
    });
  };

  const handleQuit = () => {
    toast({
      title: "Quit App",
      description: "Thank you for using Meta-Auxdior.FM-35!",
    });
  };

  return (
    <Sidebar 
      className={`${collapsed ? "w-16" : "w-72"} glass-card border-r border-card-border overflow-hidden`}
      style={{
        backgroundImage: `linear-gradient(rgba(23, 25, 35, 0.85), rgba(23, 25, 35, 0.85)), url(${sidebarWallpaper})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat'
      }}
    >
      <SidebarContent className="p-4">
        {/* Logo/Branding */}
        <div className="flex items-center gap-3 mb-8 px-2">
          <div className="w-10 h-10 rounded-xl overflow-hidden bg-gradient-primary/10 border border-music-primary/20 flex items-center justify-center">
            <img 
              src={logoImage} 
              alt="Meta-Auxdior.FM-35 Logo" 
              className="w-8 h-8 object-contain"
            />
          </div>
          {!collapsed && (
            <div>
              <h1 className="text-lg font-bold text-gradient">Meta-Auxdior.FM-35</h1>
              <p className="text-xs text-foreground-muted">AI Music Hub</p>
            </div>
          )}
        </div>

        {/* Quick Stats */}
        {!collapsed && (
          <div className="glass-card p-4 mb-6 bg-gradient-card">
            <div className="flex items-center gap-2 mb-2">
              <Volume2 className="w-4 h-4 text-music-primary" />
              <span className="text-sm font-medium">Now Playing</span>
            </div>
            <p className="text-xs text-foreground-muted mb-2">3,247 songs • 89 playlists</p>
            <div className="w-full bg-muted rounded-full h-1">
              <div className="bg-gradient-primary h-1 rounded-full w-3/4"></div>
            </div>
          </div>
        )}

        {/* Main Navigation */}
        <SidebarGroup className="mb-6">
          <SidebarGroupLabel className="text-music-primary font-semibold">
            {collapsed ? "•••" : "Premium AI Features"}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <AIRemixModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <VisualizerModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <CloudSyncModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SocialHubModal />
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* Main Navigation */}
        <SidebarGroup className="mb-6">
          <SidebarGroupLabel className="text-music-primary font-semibold">
            {collapsed ? "•••" : "Core Features"}
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={handleScanLibrary}
                  disabled={isScanning}
                  className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
                  tooltip={collapsed ? "Scan Library" : undefined}
                >
                  <Library className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
                  {!collapsed && (
                    <div className="flex items-center justify-between w-full">
                      <span className="font-medium">{isScanning ? "Scanning..." : "Scan Library"}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-music-accent/20 text-music-accent">
                        new
                      </span>
                    </div>
                  )}
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={toggleRepeat}
                  className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
                  tooltip={collapsed ? "Repeat Current" : undefined}
                >
                  <Repeat1 className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
                  {!collapsed && (
                    <div className="flex items-center justify-between w-full">
                      <span className="font-medium">Repeat Current</span>
                      {repeatMode !== 'off' && (
                        <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-music-primary/20 text-music-primary">
                          {repeatMode}
                        </span>
                      )}
                    </div>
                  )}
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <EqualizerModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <ThemeModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={toggleWidget}
                  className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
                  tooltip={collapsed ? "Widget" : undefined}
                >
                  <Square className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
                  {!collapsed && <span className="font-medium">Widget</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SleepTimerModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <HiddenModeModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton
                  className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
                  tooltip={collapsed ? "Folders" : undefined}
                >
                  <Folder className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
                  {!collapsed && <span className="font-medium">Folders</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <AudioMergerModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <AudioTrimmerModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={() => setIsDJModeActive(true)}
                  className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
                  tooltip={collapsed ? "Cross-DJ Mode" : undefined}
                >
                  <Disc3 className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
                  {!collapsed && (
                    <div className="flex items-center justify-between w-full">
                      <span className="font-medium">Cross-DJ Mode</span>
                      <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-music-accent/20 text-music-accent">
                        pro
                      </span>
                    </div>
                  )}
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={toggleDriveMode}
                  className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
                  tooltip={collapsed ? "Drive Mode" : undefined}
                >
                  <Car className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
                  {!collapsed && (
                    <div className="flex items-center justify-between w-full">
                      <span className="font-medium">Drive Mode</span>
                      <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-music-success/20 text-music-success">
                        safe
                      </span>
                    </div>
                  )}
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={toggleLyricsMode}
                  className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
                  tooltip={collapsed ? "Lyrics Mode" : undefined}
                >
                  <Music2 className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
                  {!collapsed && (
                    <div className="flex items-center justify-between w-full">
                      <span className="font-medium">Lyrics Mode</span>
                      <div className="flex items-center gap-2">
                        {isLyricsModeActive && (
                          <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-music-primary/20 text-music-primary">
                            ON
                          </span>
                        )}
                        <span className="text-xs px-2 py-0.5 rounded-full font-medium bg-music-primary/20 text-music-primary">
                          ai
                        </span>
                      </div>
                    </div>
                  )}
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <FeedbackModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SettingsModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <AboutModal />
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton
                  onClick={handleQuit}
                  className="group transition-all duration-300 hover:bg-music-primary/10 hover:shadow-glow rounded-xl"
                  tooltip={collapsed ? "Quit" : undefined}
                >
                  <LogOut className="w-5 h-5 text-music-primary group-hover:text-music-primary-glow transition-colors" />
                  {!collapsed && <span className="font-medium">Quit</span>}
                </SidebarMenuButton>
              </SidebarMenuItem>
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {/* AI Assistant Quick Access */}
        {!collapsed && (
          <div className="glass-card p-4 bg-gradient-primary/10 border border-music-primary/20">
            <div className="flex items-center gap-2 mb-2">
              <div className="w-2 h-2 bg-music-success rounded-full animate-pulse-glow"></div>
              <span className="text-sm font-medium text-music-primary">AI Assistant</span>
            </div>
            <p className="text-xs text-foreground-muted mb-3">
              "Play calm study music for focus"
            </p>
            <button className="w-full text-xs bg-music-primary/20 hover:bg-music-primary/30 text-music-primary py-2 rounded-lg transition-colors">
              Ask AI
            </button>
          </div>
        )}
      </SidebarContent>
    </Sidebar>
  );
}